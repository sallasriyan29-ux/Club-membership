# Club Membership Manager (FutureReady Hack — Project #29)

A zero-dependency Python 3.10+ interactive terminal application for managing campus club members, event participation, membership lists, threshold alerts, bulk CSV imports, and multi-format summary reports.

## Project Structure

- `main.py` — Executable CLI entry point (`python3 main.py`)
- `club_manager/models.py` — Dataclasses (`Member`, `ClubEvent`, `AttendanceRecord`, `MembershipList`, `ThresholdWarning`, `AuditEntry`, `ClubState`)
- `club_manager/validators.py` — Defensive input sanitization, regex/range validation, and safe terminal prompt wrappers
- `club_manager/logic.py` — Pure business logic engine (CRUD, attendance tracking, search/filter, KPIs, threshold warnings, bulk CSV import)
- `club_manager/storage.py` — Local CSV (`data/members.csv`) & JSON (`data/club_data.json`) persistence with corruption backup & recovery
- `club_manager/reports.py` — Multi-format report exporter (Markdown, plain-text audit log, CSV)
- `club_manager/ui.py` — Menu-driven ANSI terminal interface with fixed-width tables and pagination
- `club_manager/seed_data.py` — 40-member sample dataset covering normal, boundary, and edge cases
- `data/` — Local persistent storage (`members.csv`, `club_data.json`, `sample_bulk_import.csv`)
- `exports/` — Generated Markdown, plain-text audit log, and CSV reports
- `tests/test_club_manager.py` — `unittest` suite

## Quick Start (Terminal)

```bash
# Run interactive terminal application
python3 main.py

# Run non-interactive health check & generate initial exports
python3 main.py --check

# Run full automated test suite
python3 -m unittest discover -s tests -v
```
