#!/usr/bin/env python3
"""Club Membership Manager — Entry Point.

Zero-dependency Python 3.10+ interactive terminal application using CSV & JSON persistence.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from club_manager.logic import evaluate_threshold_warnings, generate_executive_summary
from club_manager.reports import export_all_reports
from club_manager.storage import load_state, save_state
from club_manager.ui import TerminalApp


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="club-membership-manager",
        description="Club Membership Manager — Campus & Administration Terminal Utility",
    )
    parser.add_argument(
        "--data-dir",
        default="data",
        help="Directory for CSV and JSON local persistence (default: data)",
    )
    parser.add_argument(
        "--export-dir",
        default="exports",
        help="Directory for exported Markdown, audit log, and CSV reports (default: exports)",
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable ANSI terminal color escape sequences",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Run a non-interactive health check, print executive summary, and exit",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    if args.check:
        state = load_state(Path(args.data_dir))
        save_state(state, Path(args.data_dir))
        summary = generate_executive_summary(state)
        warnings = evaluate_threshold_warnings(state)
        exports = export_all_reports(state, Path(args.export_dir))
        print(f"Club: {summary['club_name']}")
        print(f"Members: {summary['total_members']} (Active: {summary['active_members']})")
        print(f"Events: {summary['total_events']} | Lists: {summary['total_lists']}")
        print(f"Dues Collected: ${summary['collected_dues']:.2f} | Compliance: {summary['dues_compliance_pct']}%")
        print(f"Active Threshold Warnings: {len(warnings)}")
        print("Generated Exports: " + ", ".join(str(p) for p in exports.values()))
        return 0

    app = TerminalApp(
        data_dir=args.data_dir,
        export_dir=args.export_dir,
        use_color=not args.no_color,
    )
    app.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
