"""Comprehensive unit and integration tests for Club Membership Manager."""

from __future__ import annotations

import csv
import json
import tempfile
import unittest
from datetime import date
from pathlib import Path

from club_manager.logic import (
    add_member,
    add_member_to_list,
    create_event,
    create_membership_list,
    evaluate_threshold_warnings,
    filter_members,
    generate_executive_summary,
    import_members_from_rows,
    record_attendance,
    record_dues_payment,
    remove_member,
    search_members,
    update_member,
)
from club_manager.reports import export_all_reports
from club_manager.seed_data import build_sample_state
from club_manager.storage import load_state, read_bulk_csv, save_state
from club_manager.validators import (
    ValidationError,
    validate_bool,
    validate_choice,
    validate_date,
    validate_date_order,
    validate_email,
    validate_float,
    validate_full_name,
    validate_int,
    validate_student_id,
)


class ValidatorTests(unittest.TestCase):
    def test_valid_and_invalid_emails(self) -> None:
        self.assertEqual(validate_email("  Alex.Chen@Campus.EDU "), "alex.chen@campus.edu")
        with self.assertRaises(ValidationError):
            validate_email("")
        with self.assertRaises(ValidationError):
            validate_email("missing-at-symbol.edu")

    def test_student_id_validation(self) -> None:
        self.assertEqual(validate_student_id("stu-202601"), "STU-202601")
        with self.assertRaises(ValidationError):
            validate_student_id("12345")

    def test_full_name_validation(self) -> None:
        self.assertEqual(validate_full_name("  Maya   Lin  "), "Maya Lin")
        with self.assertRaises(ValidationError):
            validate_full_name("123BadName")

    def test_date_and_order_validation(self) -> None:
        self.assertEqual(validate_date("2026-11-20"), "2026-11-20")
        with self.assertRaises(ValidationError):
            validate_date("2026-02-31")
        with self.assertRaises(ValidationError):
            validate_date_order("2026-11-20", "2026-01-01")

    def test_numeric_choice_and_bool_validators(self) -> None:
        self.assertEqual(validate_int("42", "Count", 1, 100), 42)
        with self.assertRaises(ValidationError):
            validate_int("abc", "Count", 1, 100)
        with self.assertRaises(ValidationError):
            validate_int("150", "Count", 1, 100)
        self.assertEqual(validate_float("25.567", "Dues", 0.0, 500.0), 25.57)
        self.assertEqual(validate_choice("gold", ("Standard", "Silver", "Gold"), "Tier"), "Gold")
        self.assertTrue(validate_bool("YES"))
        self.assertFalse(validate_bool("no"))


class BusinessLogicTests(unittest.TestCase):
    def setUp(self) -> None:
        self.state = build_sample_state()

    def test_seed_dataset_size_and_boundaries(self) -> None:
        self.assertEqual(len(self.state.members), 40)
        self.assertGreaterEqual(len(self.state.events), 8)
        self.assertGreaterEqual(len(self.state.attendance), 40)
        self.assertEqual(len(self.state.membership_lists), 5)

    def test_add_update_renew_and_remove_member(self) -> None:
        added = add_member(
            self.state,
            full_name="Samira Khan",
            email="samira.khan@campus.edu",
            student_id="STU-202699",
            role="Member",
            membership_tier="Silver",
            status="Pending",
            dues_paid=False,
            dues_amount=45.0,
            join_date="2026-11-01",
            renewal_due_date="2026-11-10",
        )
        self.assertEqual(added.member_id, "MEM-1041")
        with self.assertRaises(ValidationError):
            add_member(
                self.state,
                full_name="Duplicate Email",
                email="samira.khan@campus.edu",
                student_id="STU-202698",
            )

        update_member(self.state, added.member_id, role="Officer")
        self.assertEqual(added.role, "Officer")

        record_dues_payment(self.state, added.member_id, amount=45.0)
        self.assertTrue(added.dues_paid)
        self.assertEqual(added.status, "Active")

        remove_member(self.state, added.member_id)
        self.assertEqual(len(self.state.members), 40)

    def test_event_capacity_and_attendance_counter(self) -> None:
        ev = create_event(
            self.state,
            title="Micro Robotics Lab",
            category="Workshop",
            event_date="2026-12-01",
            location="Lab 10",
            capacity=1,
            status="Upcoming",
        )
        m1 = self.state.members[7]
        before_count = m1.events_attended
        record_attendance(self.state, event_id=ev.event_id, member_id=m1.member_id, check_in_status="Attended")
        self.assertEqual(m1.events_attended, before_count + 1)

        with self.assertRaises(ValidationError):
            record_attendance(
                self.state,
                event_id=ev.event_id,
                member_id=self.state.members[8].member_id,
                check_in_status="RSVP",
            )

    def test_membership_list_operations(self) -> None:
        lst = create_membership_list(self.state, name="AI Ethics Panel", category="Committee")
        add_member_to_list(self.state, lst.list_id, "MEM-1008")
        self.assertIn("MEM-1008", lst.member_ids)
        with self.assertRaises(ValidationError):
            add_member_to_list(self.state, lst.list_id, "MEM-1008")

    def test_search_and_category_filtering(self) -> None:
        hits = search_members(self.state, "Robotics")
        self.assertTrue(any(m.member_id == "MEM-1006" for m in hits))
        gold_active = filter_members(self.state, status="Active", membership_tier="Gold")
        self.assertTrue(all(m.status == "Active" and m.membership_tier == "Gold" for m in gold_active))
        self.assertGreaterEqual(len(gold_active), 5)

    def test_summary_and_threshold_warnings(self) -> None:
        ref = date(2026, 11, 20)
        summary = generate_executive_summary(self.state, reference_date=ref)
        self.assertEqual(summary["total_members"], 40)
        self.assertGreater(summary["collected_dues"], 0)
        warnings = evaluate_threshold_warnings(self.state, reference_date=ref)
        codes = {w.code for w in warnings}
        self.assertIn("OVERDUE_RENEWAL", codes)
        self.assertIn("UNPAID_ACTIVE_DUES", codes)
        self.assertIn("EVENT_NEAR_CAPACITY", codes)
        self.assertIn("ZERO_ENGAGEMENT", codes)


class PersistenceAndExportTests(unittest.TestCase):
    def test_save_reload_and_corruption_recovery(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_dir = Path(tmp)
            state = build_sample_state()
            csv_path, json_path = save_state(state, tmp_dir)
            self.assertTrue(csv_path.exists())
            self.assertTrue(json_path.exists())

            reloaded = load_state(tmp_dir)
            self.assertEqual(len(reloaded.members), 40)
            self.assertEqual(len(reloaded.events), 8)

            # Corrupt JSON file and verify graceful recovery from CSV + backup
            json_path.write_text("{broken json!!!", encoding="utf-8")
            recovered = load_state(tmp_dir)
            self.assertEqual(len(recovered.members), 40)
            self.assertTrue(any("corrupted JSON" in msg for msg in recovered.startup_notices))
            backups = list(tmp_dir.glob("club_data.json.corrupt.*.bak"))
            self.assertEqual(len(backups), 1)

    def test_bulk_import_diagnostics(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_csv = Path(tmp) / "import.csv"
            with tmp_csv.open("w", encoding="utf-8", newline="") as fh:
                writer = csv.writer(fh)
                writer.writerow([
                    "member_id", "full_name", "email", "student_id", "role", "membership_tier",
                    "status", "dues_paid", "dues_amount", "join_date", "renewal_due_date", "events_attended", "notes",
                ])
                writer.writerow(["", "Valid Student", "valid.student@campus.edu", "STU-900001", "Member", "Standard", "Active", "true", "25.00", "2026-11-01", "2027-11-01", "1", "Clean row"])
                writer.writerow(["", "Bad Email", "invalid-email", "STU-900002", "Member", "Standard", "Active", "true", "25.00", "2026-11-01", "2027-11-01", "0", "Broken email"])

            state = build_sample_state()
            rows = read_bulk_csv(tmp_csv)
            result = import_members_from_rows(state, rows)
            self.assertEqual(result["imported_count"], 1)
            self.assertEqual(result["failed_count"], 1)
            self.assertEqual(len(state.members), 41)

    def test_multi_format_report_exports(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            export_dir = Path(tmp) / "exports"
            state = build_sample_state()
            paths = export_all_reports(state, export_dir)
            self.assertTrue(paths["markdown"].exists())
            self.assertTrue(paths["audit_log"].exists())
            self.assertTrue(paths["members_csv"].exists())
            self.assertTrue(paths["metrics_csv"].exists())

            md_text = paths["markdown"].read_text(encoding="utf-8")
            self.assertIn("Executive Summary Report", md_text)
            txt_text = paths["audit_log"].read_text(encoding="utf-8")
            self.assertIn("CHRONOLOGICAL AUDIT TRAIL", txt_text)


if __name__ == "__main__":
    unittest.main()
