"""Domain models and constants for Club Membership Manager."""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any

VALID_ROLES = ("Member", "Officer", "Treasurer", "Secretary", "Vice President", "President", "Advisor")
VALID_TIERS = ("Standard", "Silver", "Gold", "Honorary")
VALID_MEMBER_STATUSES = ("Active", "Pending", "Inactive", "Alumni", "Suspended")
VALID_EVENT_CATEGORIES = ("Workshop", "General Meeting", "Hackathon", "Social", "Community Service", "Competition")
VALID_EVENT_STATUSES = ("Upcoming", "Ongoing", "Completed", "Cancelled")
VALID_CHECKIN_STATUSES = ("Attended", "RSVP", "Excused", "No-Show")

TIER_DUES_DEFAULTS: dict[str, float] = {
    "Standard": 25.00,
    "Silver": 45.00,
    "Gold": 75.00,
    "Honorary": 0.00,
}


@dataclass
class Member:
    """Represents an individual club member record."""

    member_id: str
    full_name: str
    email: str
    student_id: str
    role: str = "Member"
    membership_tier: str = "Standard"
    status: str = "Active"
    dues_paid: bool = False
    dues_amount: float = 25.0
    join_date: str = ""
    renewal_due_date: str = ""
    events_attended: int = 0
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Member:
        return cls(
            member_id=str(data.get("member_id", "")).strip(),
            full_name=str(data.get("full_name", "")).strip(),
            email=str(data.get("email", "")).strip().lower(),
            student_id=str(data.get("student_id", "")).strip().upper(),
            role=str(data.get("role", "Member")).strip(),
            membership_tier=str(data.get("membership_tier", "Standard")).strip(),
            status=str(data.get("status", "Active")).strip(),
            dues_paid=_parse_bool(data.get("dues_paid", False)),
            dues_amount=float(data.get("dues_amount", 25.0)),
            join_date=str(data.get("join_date", "")).strip(),
            renewal_due_date=str(data.get("renewal_due_date", "")).strip(),
            events_attended=int(data.get("events_attended", 0)),
            notes=str(data.get("notes", "")).strip(),
        )


@dataclass
class ClubEvent:
    """Represents a scheduled or past club event."""

    event_id: str
    title: str
    category: str
    event_date: str
    location: str
    capacity: int
    status: str = "Upcoming"
    description: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ClubEvent:
        return cls(
            event_id=str(data.get("event_id", "")).strip(),
            title=str(data.get("title", "")).strip(),
            category=str(data.get("category", "General Meeting")).strip(),
            event_date=str(data.get("event_date", "")).strip(),
            location=str(data.get("location", "")).strip(),
            capacity=int(data.get("capacity", 30)),
            status=str(data.get("status", "Upcoming")).strip(),
            description=str(data.get("description", "")).strip(),
        )


@dataclass
class AttendanceRecord:
    """Links a member to an event participation record."""

    record_id: str
    event_id: str
    member_id: str
    check_in_status: str = "Attended"
    hours_credited: float = 2.0
    recorded_at: str = ""
    feedback_score: int = 5

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AttendanceRecord:
        return cls(
            record_id=str(data.get("record_id", "")).strip(),
            event_id=str(data.get("event_id", "")).strip(),
            member_id=str(data.get("member_id", "")).strip(),
            check_in_status=str(data.get("check_in_status", "Attended")).strip(),
            hours_credited=float(data.get("hours_credited", 2.0)),
            recorded_at=str(data.get("recorded_at", "")).strip(),
            feedback_score=int(data.get("feedback_score", 5)),
        )


@dataclass
class MembershipList:
    """Represents a named roster, committee, or segmented membership list."""

    list_id: str
    name: str
    category: str
    description: str = ""
    member_ids: list[str] = field(default_factory=list)
    created_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MembershipList:
        raw_ids = data.get("member_ids", [])
        if isinstance(raw_ids, list):
            ids = [str(item).strip() for item in raw_ids if str(item).strip()]
        else:
            ids = []
        return cls(
            list_id=str(data.get("list_id", "")).strip(),
            name=str(data.get("name", "")).strip(),
            category=str(data.get("category", "Committee")).strip(),
            description=str(data.get("description", "")).strip(),
            member_ids=ids,
            created_at=str(data.get("created_at", "")).strip(),
        )


@dataclass
class ThresholdWarning:
    """Automated anomaly, overdue deadline, or limit breach warning."""

    severity: str  # CRITICAL, WARNING, INFO
    code: str
    entity_type: str
    entity_id: str
    message: str


@dataclass
class AuditEntry:
    """Records state-changing operations for plain-text audit logs."""

    timestamp: str
    action: str
    entity_id: str
    details: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AuditEntry:
        return cls(
            timestamp=str(data.get("timestamp", "")).strip(),
            action=str(data.get("action", "")).strip(),
            entity_id=str(data.get("entity_id", "")).strip(),
            details=str(data.get("details", "")).strip(),
        )


@dataclass
class ClubState:
    """In-memory aggregate state for the Club Membership Manager."""

    club_name: str = "Campus Innovators & Builders Club"
    members: list[Member] = field(default_factory=list)
    events: list[ClubEvent] = field(default_factory=list)
    attendance: list[AttendanceRecord] = field(default_factory=list)
    membership_lists: list[MembershipList] = field(default_factory=list)
    audit_log: list[AuditEntry] = field(default_factory=list)
    startup_notices: list[str] = field(default_factory=list)


def _parse_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    return text in ("true", "1", "yes", "y", "paid")
