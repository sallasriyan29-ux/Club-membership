"""Multi-format summary export engine (Markdown, Plain-Text Audit Log, CSV)."""

from __future__ import annotations

import csv
from datetime import date, datetime
from pathlib import Path
from typing import Optional

from club_manager.logic import evaluate_threshold_warnings, generate_executive_summary
from club_manager.models import ClubState
from club_manager.storage import MEMBER_CSV_FIELDS


def export_markdown_report(
    state: ClubState,
    export_dir: str | Path = "exports",
    reference_date: Optional[date] = None,
) -> Path:
    """Export an executive summary and threshold warning report in Markdown format."""
    out_dir = Path(export_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "club_summary_report.md"

    summary = generate_executive_summary(state, reference_date=reference_date)
    warnings = evaluate_threshold_warnings(state, reference_date=reference_date)

    lines = [
        f"# {state.club_name} — Executive Summary Report",
        "",
        f"- **Generated At:** {summary['generated_at']}",
        f"- **Club Health Status:** `{summary['health_indicator']}`",
        f"- **Total Members:** {summary['total_members']} ({summary['active_members']} Active, {summary['retention_rate_pct']}% Active Rate)",
        f"- **Events Tracked:** {summary['total_events']} ({summary['total_attendance_records']} participation records)",
        f"- **Membership Lists:** {summary['total_lists']}",
        "",
        "## Financial & Engagement KPIs",
        "",
        "| Metric | Value |",
        "| :--- | :--- |",
        f"| Dues Collected | ${summary['collected_dues']:.2f} |",
        f"| Outstanding Dues | ${summary['outstanding_dues']:.2f} |",
        f"| Dues Compliance Rate | {summary['dues_compliance_pct']}% |",
        f"| Avg Events Attended / Member | {summary['avg_events_per_member']} |",
        f"| Total Volunteer / Lab Hours | {summary['total_hours_credited']} hrs |",
        f"| Average Event Feedback | {summary['avg_event_feedback']} / 5.0 |",
        "",
        "## Membership Status Breakdown",
        "",
        "| Status | Count |",
        "| :--- | ---: |",
    ]
    for status, count in sorted(summary["status_breakdown"].items()):
        lines.append(f"| {status} | {count} |")

    lines.extend([
        "",
        "## Membership Tier Breakdown",
        "",
        "| Tier | Count |",
        "| :--- | ---: |",
    ])
    for tier, count in sorted(summary["tier_breakdown"].items()):
        lines.append(f"| {tier} | {count} |")

    lines.extend([
        "",
        "## Top Engaged Members",
        "",
        "| Member ID | Name | Role | Tier | Events Attended |",
        "| :--- | :--- | :--- | :--- | ---: |",
    ])
    for m in summary["top_members"]:
        lines.append(
            f"| {m['member_id']} | {m['full_name']} | {m['role']} | {m['tier']} | {m['events_attended']} |"
        )

    lines.extend([
        "",
        "## Threshold Warnings & Anomalies",
        "",
    ])
    if not warnings:
        lines.append("No threshold warnings or anomalies detected.")
    else:
        lines.append("| Severity | Code | Entity | Message |")
        lines.append("| :--- | :--- | :--- | :--- |")
        for w in warnings:
            lines.append(f"| **{w.severity}** | `{w.code}` | {w.entity_type} `{w.entity_id}` | {w.message} |")

    lines.append("")
    out_path.write_text("\n".join(lines), encoding="utf-8")
    return out_path


def export_audit_log(
    state: ClubState,
    export_dir: str | Path = "exports",
    reference_date: Optional[date] = None,
) -> Path:
    """Export a plain-text operational audit log and threshold alert digest."""
    out_dir = Path(export_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "club_audit_log.txt"

    warnings = evaluate_threshold_warnings(state, reference_date=reference_date)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines = [
        "=" * 78,
        f"CLUB MEMBERSHIP MANAGER — PLAIN-TEXT AUDIT LOG",
        f"Organization : {state.club_name}",
        f"Exported At  : {timestamp}",
        f"Total Audits : {len(state.audit_log)}",
        f"Active Alerts: {len(warnings)}",
        "=" * 78,
        "",
        "[SECTION 1: CHRONOLOGICAL AUDIT TRAIL]",
        "-" * 78,
    ]
    if not state.audit_log:
        lines.append("(No audit entries recorded)")
    else:
        for idx, entry in enumerate(state.audit_log, start=1):
            lines.append(f"{idx:03d}. [{entry.timestamp}] {entry.action:<18} | {entry.entity_id:<10} | {entry.details}")

    lines.extend([
        "",
        "[SECTION 2: ACTIVE THRESHOLD WARNINGS]",
        "-" * 78,
    ])
    if not warnings:
        lines.append("All thresholds within healthy operating parameters.")
    else:
        for idx, w in enumerate(warnings, start=1):
            lines.append(f"{idx:03d}. [{w.severity:<8}] {w.code:<22} | {w.entity_id:<10} | {w.message}")

    lines.append("")
    out_path.write_text("\n".join(lines), encoding="utf-8")
    return out_path


def export_csv_reports(
    state: ClubState,
    export_dir: str | Path = "exports",
    reference_date: Optional[date] = None,
) -> tuple[Path, Path]:
    """Export standardized CSV member roster and summary KPI CSV reports."""
    out_dir = Path(export_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    members_csv_path = out_dir / "club_members_report.csv"
    with members_csv_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=MEMBER_CSV_FIELDS)
        writer.writeheader()
        for member in state.members:
            row = member.to_dict()
            row["dues_paid"] = "Yes" if member.dues_paid else "No"
            row["dues_amount"] = f"{member.dues_amount:.2f}"
            writer.writerow({k: row[k] for k in MEMBER_CSV_FIELDS})

    summary = generate_executive_summary(state, reference_date=reference_date)
    metrics_csv_path = out_dir / "club_summary_metrics.csv"
    with metrics_csv_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["Category", "Metric", "Value"])
        writer.writerow(["Overview", "Club Name", summary["club_name"]])
        writer.writerow(["Overview", "Generated At", summary["generated_at"]])
        writer.writerow(["Overview", "Health Indicator", summary["health_indicator"]])
        writer.writerow(["Overview", "Total Members", summary["total_members"]])
        writer.writerow(["Overview", "Active Members", summary["active_members"]])
        writer.writerow(["Overview", "Active Rate (%)", summary["retention_rate_pct"]])
        writer.writerow(["Finance", "Dues Collected ($)", f"{summary['collected_dues']:.2f}"])
        writer.writerow(["Finance", "Outstanding Dues ($)", f"{summary['outstanding_dues']:.2f}"])
        writer.writerow(["Finance", "Dues Compliance (%)", summary["dues_compliance_pct"]])
        writer.writerow(["Engagement", "Total Events", summary["total_events"]])
        writer.writerow(["Engagement", "Avg Events Attended / Member", summary["avg_events_per_member"]])
        writer.writerow(["Engagement", "Total Hours Credited", summary["total_hours_credited"]])
        writer.writerow(["Engagement", "Avg Event Feedback (1-5)", summary["avg_event_feedback"]])
        for status, count in sorted(summary["status_breakdown"].items()):
            writer.writerow(["Status Breakdown", status, count])
        for tier, count in sorted(summary["tier_breakdown"].items()):
            writer.writerow(["Tier Breakdown", tier, count])

    return members_csv_path, metrics_csv_path


def export_all_reports(
    state: ClubState,
    export_dir: str | Path = "exports",
    reference_date: Optional[date] = None,
) -> dict[str, Path]:
    """Generate Markdown, Plain-Text Audit Log, and CSV reports in one pass."""
    md_path = export_markdown_report(state, export_dir, reference_date=reference_date)
    txt_path = export_audit_log(state, export_dir, reference_date=reference_date)
    members_csv, metrics_csv = export_csv_reports(state, export_dir, reference_date=reference_date)
    return {
        "markdown": md_path,
        "audit_log": txt_path,
        "members_csv": members_csv,
        "metrics_csv": metrics_csv,
    }
