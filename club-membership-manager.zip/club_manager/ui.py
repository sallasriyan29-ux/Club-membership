"""Interactive terminal console interface for Club Membership Manager."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, Callable, Optional, Sequence

from club_manager import __version__
from club_manager.logic import (
    add_member,
    add_member_to_list,
    create_event,
    create_membership_list,
    evaluate_threshold_warnings,
    filter_members,
    generate_executive_summary,
    get_event_by_id,
    get_event_roster,
    get_list_by_id,
    get_list_members,
    get_member_by_id,
    import_members_from_rows,
    record_attendance,
    record_dues_payment,
    remove_member,
    remove_member_from_list,
    search_members,
    update_member,
)
from club_manager.models import (
    ClubEvent,
    ClubState,
    Member,
    TIER_DUES_DEFAULTS,
    VALID_CHECKIN_STATUSES,
    VALID_EVENT_CATEGORIES,
    VALID_EVENT_STATUSES,
    VALID_MEMBER_STATUSES,
    VALID_ROLES,
    VALID_TIERS,
)
from club_manager.reports import (
    export_all_reports,
    export_audit_log,
    export_csv_reports,
    export_markdown_report,
)
from club_manager.storage import StorageError, load_state, read_bulk_csv, save_state
from club_manager.validators import (
    ValidationError,
    prompt_choice,
    prompt_confirm,
    prompt_validated,
    safe_read_line,
    sanitize_text,
    validate_bool,
    validate_date,
    validate_date_order,
    validate_email,
    validate_float,
    validate_full_name,
    validate_int,
    validate_member_id,
    validate_non_empty,
    validate_student_id,
)


class AnsiPalette:
    """Optional ANSI color helper that degrades cleanly when disabled."""

    def __init__(self, enabled: bool = True) -> None:
        self.enabled = enabled and not os.environ.get("NO_COLOR")

    def wrap(self, code: str, text: str) -> str:
        if not self.enabled:
            return text
        return f"\033[{code}m{text}\033[0m"

    def bold(self, text: str) -> str:
        return self.wrap("1", text)

    def cyan(self, text: str) -> str:
        return self.wrap("36", text)

    def green(self, text: str) -> str:
        return self.wrap("32", text)

    def yellow(self, text: str) -> str:
        return self.wrap("33", text)

    def red(self, text: str) -> str:
        return self.wrap("31", text)

    def dim(self, text: str) -> str:
        return self.wrap("2", text)


class TerminalApp:
    """Menu-driven CLI application controller."""

    def __init__(
        self,
        data_dir: str | Path = "data",
        export_dir: str | Path = "exports",
        use_color: bool = True,
        page_size: int = 12,
    ) -> None:
        self.data_dir = Path(data_dir)
        self.export_dir = Path(export_dir)
        self.palette = AnsiPalette(use_color)
        self.page_size = page_size
        self.state: ClubState = load_state(self.data_dir)
        self.running = True

    # ------------------------------------------------------------------
    # Output Helpers
    # ------------------------------------------------------------------

    def print_ok(self, message: str) -> None:
        print(f"\n  {self.palette.green('[OK]')} {message}")

    def print_warn(self, message: str) -> None:
        print(f"  {self.palette.yellow('[WARN]')} {message}")

    def print_err(self, message: str) -> None:
        print(f"  {self.palette.red('[ERROR]')} {message}")

    def print_header(self, title: str) -> None:
        bar = "=" * 78
        print(f"\n{self.palette.cyan(bar)}")
        print(self.palette.bold(f"  {title}"))
        print(self.palette.cyan(bar))

    def pause(self) -> None:
        try:
            safe_read_line(self.palette.dim("\nPress [Enter] to continue... "))
        except EOFError:
            pass

    @staticmethod
    def _truncate(text: str, width: int) -> str:
        if len(text) <= width:
            return text
        if width <= 3:
            return text[:width]
        return text[: width - 3] + "..."

    def render_table(
        self,
        headers: Sequence[str],
        rows: Sequence[Sequence[str]],
        widths: Sequence[int],
        title: Optional[str] = None,
        paginate: bool = True,
    ) -> None:
        if title:
            print(f"\n{self.palette.bold(title)} ({len(rows)} record(s))")
        if not rows:
            print("  (No matching records to display.)")
            return

        sep = "+-" + "-+-".join("-" * w for w in widths) + "-+"
        header_line = "| " + " | ".join(self._truncate(h, w).ljust(w) for h, w in zip(headers, widths)) + " |"

        total_pages = max(1, (len(rows) + self.page_size - 1) // self.page_size) if paginate else 1
        page = 0

        while True:
            start = page * self.page_size if paginate else 0
            end = min(len(rows), start + self.page_size) if paginate else len(rows)
            chunk = rows[start:end]

            print(sep)
            print(self.palette.bold(header_line))
            print(sep)
            for row in chunk:
                formatted_cells = [self._truncate(str(val), w).ljust(w) for val, w in zip(row, widths)]
                print("| " + " | ".join(formatted_cells) + " |")
            print(sep)

            if not paginate or total_pages == 1:
                break

            print(
                self.palette.dim(
                    f"  Page {page + 1}/{total_pages} | Showing {start + 1}-{end} of {len(rows)} "
                    f"| [N]ext, [P]rev, [Q]uit view"
                )
            )
            try:
                nav = sanitize_text(safe_read_line("  Table navigation [N/P/Q]: ")).lower()
            except EOFError:
                break
            if nav in ("n", "next", ""):
                if page + 1 < total_pages:
                    page += 1
                else:
                    break
            elif nav in ("p", "prev"):
                if page > 0:
                    page -= 1
                else:
                    self.print_warn("Already on the first page.")
            elif nav in ("q", "quit", "back", "b"):
                break
            else:
                self.print_warn("Enter N (next), P (previous), or Q (quit table view).")

    def render_members_table(self, members: list[Member], title: str = "Member Directory", paginate: bool = True) -> None:
        headers = ("ID", "Full Name", "Role", "Tier", "Status", "Dues", "Events", "Renewal Due")
        widths = (8, 20, 14, 8, 9, 8, 6, 10)
        rows = [
            (
                m.member_id,
                m.full_name,
                m.role,
                m.membership_tier,
                m.status,
                f"{'PD' if m.dues_paid else 'UNP'} ${m.dues_amount:.0f}",
                str(m.events_attended),
                m.renewal_due_date,
            )
            for m in members
        ]
        self.render_table(headers, rows, widths, title=title, paginate=paginate)

    # ------------------------------------------------------------------
    # Welcome & Main Menu
    # ------------------------------------------------------------------

    def show_welcome(self) -> None:
        summary = generate_executive_summary(self.state)
        warnings = evaluate_threshold_warnings(self.state)
        banner = [
            "+" + "=" * 76 + "+",
            "|  CLUB MEMBERSHIP MANAGER v" + __version__.ljust(49) + "|",
            "|  " + f"{self.state.club_name} — Campus & Administration".ljust(74) + "|",
            "+" + "=" * 76 + "+",
        ]
        print("\n" + self.palette.cyan("\n".join(banner)))
        print(
            f"  Members: {self.palette.bold(str(summary['total_members']))} "
            f"({summary['active_members']} Active)  |  "
            f"Events: {self.palette.bold(str(summary['total_events']))}  |  "
            f"Lists: {self.palette.bold(str(summary['total_lists']))}  |  "
            f"Alerts: {self.palette.yellow(str(len(warnings))) if warnings else self.palette.green('0')}"
        )
        if self.state.startup_notices:
            print("")
            for note in self.state.startup_notices:
                self.print_warn(note)
            self.state.startup_notices.clear()

    def show_main_menu(self) -> None:
        self.print_header("MAIN MENU")
        options = [
            ("1", "Member Directory (View, Add, Update, Renew Dues, Remove)"),
            ("2", "Search & Filter Records (Keyword Search & Category Filter)"),
            ("3", "Event Participation (View Events, Create Event, Record Check-In)"),
            ("4", "Membership Lists & Committees (Rosters & Group Assignments)"),
            ("5", "Executive Summary & Analytics (KPIs, Trends, ASCII Charts)"),
            ("6", "Threshold Warnings & Anomaly Scan (Overdue & Capacity Flags)"),
            ("7", "Bulk CSV Dataset Import (Validate & Ingest Legacy CSV)"),
            ("8", "Export Reports (Markdown, Plain-Text Audit Log, CSV)"),
            ("9", "Save & Reload Storage (Verify Local CSV/JSON Persistence)"),
            ("0", "Save & Exit Application"),
        ]
        for key, label in options:
            print(f"  [{self.palette.cyan(key)}] {label}")

    def run(self) -> None:
        self.show_welcome()
        while self.running:
            try:
                self.show_main_menu()
                choice = sanitize_text(safe_read_line("\nSelect menu option [0-9]: "))
                self.dispatch_main(choice)
            except EOFError:
                print("\nEnd of input detected. Saving and exiting...")
                save_state(self.state, self.data_dir)
                self.running = False
            except KeyboardInterrupt:
                print("\nInterrupted. Returning to main menu (enter 0 to save & exit).")

    def dispatch_main(self, choice: str) -> None:
        handlers: dict[str, Callable[[], None]] = {
            "1": self.menu_members,
            "2": self.menu_search,
            "3": self.menu_events,
            "4": self.menu_lists,
            "5": self.menu_summary,
            "6": self.menu_warnings,
            "7": self.menu_bulk_import,
            "8": self.menu_exports,
            "9": self.menu_storage,
            "0": self.exit_app,
        }
        handler = handlers.get(choice)
        if handler is None:
            self.print_err(f"Invalid selection '{choice}'. Please enter a digit from 0 to 9.")
            return
        handler()

    def exit_app(self) -> None:
        csv_path, json_path = save_state(self.state, self.data_dir)
        self.print_ok(f"All records saved to '{csv_path}' and '{json_path}'.")
        print("Goodbye from Club Membership Manager!")
        self.running = False

    # ------------------------------------------------------------------
    # 1. Member Directory
    # ------------------------------------------------------------------

    def menu_members(self) -> None:
        while True:
            self.print_header("MEMBER DIRECTORY")
            print("  [1] View All Members (Paginated Table)")
            print("  [2] Add New Member")
            print("  [3] Update Member Profile")
            print("  [4] Record Dues Payment & Renew Membership")
            print("  [5] Remove Member")
            print("  [0] Return to Main Menu")
            choice = sanitize_text(safe_read_line("\nMember Directory option [0-5]: "))
            if choice == "1":
                self.render_members_table(self.state.members, title="All Club Members", paginate=True)
            elif choice == "2":
                self.flow_add_member()
            elif choice == "3":
                self.flow_update_member()
            elif choice == "4":
                self.flow_renew_dues()
            elif choice == "5":
                self.flow_remove_member()
            elif choice == "0":
                return
            else:
                self.print_err(f"Invalid option '{choice}'. Choose 0-5.")

    def flow_add_member(self) -> None:
        self.print_header("ADD NEW MEMBER")
        print("  Enter 'cancel' at any prompt to abort.\n")

        full_name = prompt_validated("Full Name", validate_full_name, error_printer=self.print_err)
        if full_name is None:
            return

        email = prompt_validated("Campus Email", validate_email, error_printer=self.print_err)
        if email is None:
            return

        student_id = prompt_validated("Student ID (e.g. STU-202601)", validate_student_id, error_printer=self.print_err)
        if student_id is None:
            return

        role = prompt_choice("Club Role", VALID_ROLES, default="Member", error_printer=self.print_err)
        if role is None:
            return

        tier = prompt_choice("Membership Tier", VALID_TIERS, default="Standard", error_printer=self.print_err)
        if tier is None:
            return

        status = prompt_choice("Initial Status", VALID_MEMBER_STATUSES, default="Active", error_printer=self.print_err)
        if status is None:
            return

        default_fee = f"{TIER_DUES_DEFAULTS.get(tier, 25.0):.2f}"
        dues_amount = prompt_validated(
            "Dues Amount ($)",
            lambda v: validate_float(v, "Dues amount", 0.0, 2000.0),
            default=default_fee,
            error_printer=self.print_err,
        )
        if dues_amount is None:
            return

        dues_paid = prompt_validated(
            "Dues Paid? (y/n)",
            lambda v: validate_bool(v, "Dues paid"),
            default="y" if float(dues_amount) == 0 else "n",
            error_printer=self.print_err,
        )
        if dues_paid is None:
            return

        from datetime import date, timedelta

        today_str = date.today().isoformat()
        next_year_str = (date.today() + timedelta(days=365)).isoformat()

        join_date = prompt_validated(
            "Join Date (YYYY-MM-DD)",
            lambda v: validate_date(v, "Join date"),
            default=today_str,
            error_printer=self.print_err,
        )
        if join_date is None:
            return

        def _validate_renewal(raw: str) -> str:
            parsed = validate_date(raw, "Renewal due date")
            validate_date_order(str(join_date), parsed, "Join date", "Renewal due date")
            return parsed

        renewal_due = prompt_validated(
            "Renewal Due Date (YYYY-MM-DD)",
            _validate_renewal,
            default=next_year_str,
            error_printer=self.print_err,
        )
        if renewal_due is None:
            return

        notes = prompt_validated(
            "Notes (optional)",
            lambda v: sanitize_text(v)[:200],
            default="",
            error_printer=self.print_err,
        )
        if notes is None:
            return

        try:
            member = add_member(
                self.state,
                full_name=str(full_name),
                email=str(email),
                student_id=str(student_id),
                role=role,
                membership_tier=tier,
                status=status,
                dues_paid=bool(dues_paid),
                dues_amount=float(dues_amount),
                join_date=str(join_date),
                renewal_due_date=str(renewal_due),
                notes=str(notes),
            )
            save_state(self.state, self.data_dir)
            self.print_ok(f"Added member {member.member_id}: {member.full_name} ({member.membership_tier}, {member.status}).")
        except ValidationError as err:
            self.print_err(str(err))

    def flow_update_member(self) -> None:
        self.print_header("UPDATE MEMBER PROFILE")
        member_id = prompt_validated("Member ID (e.g. MEM-1001)", validate_member_id, error_printer=self.print_err)
        if member_id is None:
            return
        member = get_member_by_id(self.state, str(member_id))
        if member is None:
            self.print_err(f"Member '{member_id}' not found.")
            return

        print(f"\n  Editing {member.member_id} — {member.full_name} ({member.email})")
        full_name = prompt_validated("Full Name", validate_full_name, default=member.full_name, error_printer=self.print_err)
        if full_name is None:
            return
        role = prompt_choice("Club Role", VALID_ROLES, default=member.role, error_printer=self.print_err)
        if role is None:
            return
        tier = prompt_choice("Membership Tier", VALID_TIERS, default=member.membership_tier, error_printer=self.print_err)
        if tier is None:
            return
        status = prompt_choice("Status", VALID_MEMBER_STATUSES, default=member.status, error_printer=self.print_err)
        if status is None:
            return
        notes = prompt_validated("Notes", lambda v: sanitize_text(v)[:200], default=member.notes, error_printer=self.print_err)
        if notes is None:
            return

        try:
            updated = update_member(
                self.state,
                member.member_id,
                full_name=str(full_name),
                role=role,
                membership_tier=tier,
                status=status,
                notes=str(notes),
            )
            save_state(self.state, self.data_dir)
            self.print_ok(f"Updated {updated.member_id} ({updated.full_name}).")
        except ValidationError as err:
            self.print_err(str(err))

    def flow_renew_dues(self) -> None:
        self.print_header("RECORD DUES PAYMENT & RENEW")
        member_id = prompt_validated("Member ID (e.g. MEM-1009)", validate_member_id, error_printer=self.print_err)
        if member_id is None:
            return
        member = get_member_by_id(self.state, str(member_id))
        if member is None:
            self.print_err(f"Member '{member_id}' not found.")
            return

        print(
            f"  Current status: {member.status} | Paid: {'Yes' if member.dues_paid else 'No'} "
            f"| Amount: ${member.dues_amount:.2f} | Due: {member.renewal_due_date}"
        )
        amount = prompt_validated(
            "Payment Amount ($)",
            lambda v: validate_float(v, "Payment amount", 0.0, 2000.0),
            default=f"{member.dues_amount:.2f}",
            error_printer=self.print_err,
        )
        if amount is None:
            return
        try:
            updated = record_dues_payment(self.state, member.member_id, amount=float(amount))
            save_state(self.state, self.data_dir)
            self.print_ok(
                f"Recorded ${updated.dues_amount:.2f} for {updated.full_name}. "
                f"Status={updated.status}, Next Renewal={updated.renewal_due_date}."
            )
        except ValidationError as err:
            self.print_err(str(err))

    def flow_remove_member(self) -> None:
        self.print_header("REMOVE MEMBER")
        member_id = prompt_validated("Member ID to remove", validate_member_id, error_printer=self.print_err)
        if member_id is None:
            return
        member = get_member_by_id(self.state, str(member_id))
        if member is None:
            self.print_err(f"Member '{member_id}' not found.")
            return
        if not prompt_confirm(f"Confirm permanent removal of {member.member_id} ({member.full_name})?", default=False):
            self.print_warn("Removal cancelled.")
            return
        removed = remove_member(self.state, member.member_id)
        save_state(self.state, self.data_dir)
        self.print_ok(f"Removed {removed.member_id} ({removed.full_name}) and cascaded event/list references.")

    # ------------------------------------------------------------------
    # 2. Search & Filter
    # ------------------------------------------------------------------

    def menu_search(self) -> None:
        while True:
            self.print_header("SEARCH & FILTER RECORDS")
            print("  [1] Keyword Search (Name, Email, ID, Notes)")
            print("  [2] Category Filter (Status, Tier, Role, Dues Status)")
            print("  [0] Return to Main Menu")
            choice = sanitize_text(safe_read_line("\nSearch option [0-2]: "))
            if choice == "1":
                kw = prompt_validated(
                    "Enter search keyword",
                    lambda v: validate_non_empty(v, "Keyword", 1, 60),
                    error_printer=self.print_err,
                )
                if kw is None:
                    continue
                matches = search_members(self.state, str(kw))
                if not matches:
                    self.print_warn(f"No members matched keyword '{kw}'.")
                else:
                    self.render_members_table(matches, title=f"Search Results for '{kw}'", paginate=True)
            elif choice == "2":
                self.flow_category_filter()
            elif choice == "0":
                return
            else:
                self.print_err(f"Invalid option '{choice}'. Choose 0-2.")

    def flow_category_filter(self) -> None:
        print("\n  Select filter value or press [Enter] for 'ALL':")
        status_opts = ("ALL",) + VALID_MEMBER_STATUSES
        tier_opts = ("ALL",) + VALID_TIERS
        role_opts = ("ALL",) + VALID_ROLES

        status_sel = prompt_choice("Filter by Status", status_opts, default="ALL", error_printer=self.print_err)
        if status_sel is None:
            return
        tier_sel = prompt_choice("Filter by Tier", tier_opts, default="ALL", error_printer=self.print_err)
        if tier_sel is None:
            return
        role_sel = prompt_choice("Filter by Role", role_opts, default="ALL", error_printer=self.print_err)
        if role_sel is None:
            return
        dues_sel = prompt_choice("Filter by Dues Paid", ("ALL", "Paid", "Unpaid"), default="ALL", error_printer=self.print_err)
        if dues_sel is None:
            return

        dues_bool: Optional[bool] = None
        if dues_sel == "Paid":
            dues_bool = True
        elif dues_sel == "Unpaid":
            dues_bool = False

        results = filter_members(
            self.state,
            status=None if status_sel == "ALL" else status_sel,
            membership_tier=None if tier_sel == "ALL" else tier_sel,
            role=None if role_sel == "ALL" else role_sel,
            dues_paid=dues_bool,
        )
        if not results:
            self.print_warn("No member records matched the selected category filters.")
        else:
            self.render_members_table(results, title="Filtered Member Records", paginate=True)

    # ------------------------------------------------------------------
    # 3. Event Participation
    # ------------------------------------------------------------------

    def menu_events(self) -> None:
        while True:
            self.print_header("EVENT PARTICIPATION")
            print("  [1] View All Events & Utilization")
            print("  [2] Create New Club Event")
            print("  [3] Record Member Attendance / Check-In")
            print("  [4] View Event Attendance Roster")
            print("  [0] Return to Main Menu")
            choice = sanitize_text(safe_read_line("\nEvent option [0-4]: "))
            if choice == "1":
                self.show_events_table()
            elif choice == "2":
                self.flow_create_event()
            elif choice == "3":
                self.flow_record_attendance()
            elif choice == "4":
                self.flow_view_event_roster()
            elif choice == "0":
                return
            else:
                self.print_err(f"Invalid option '{choice}'. Choose 0-4.")

    def show_events_table(self) -> None:
        headers = ("ID", "Title", "Category", "Date", "Status", "Reg/Cap", "Location")
        widths = (7, 26, 15, 10, 10, 7, 18)
        rows = []
        for ev in self.state.events:
            reg = sum(
                1 for a in self.state.attendance if a.event_id == ev.event_id and a.check_in_status in ("Attended", "RSVP")
            )
            rows.append((ev.event_id, ev.title, ev.category, ev.event_date, ev.status, f"{reg}/{ev.capacity}", ev.location))
        self.render_table(headers, rows, widths, title="Club Events", paginate=True)

    def flow_create_event(self) -> None:
        self.print_header("CREATE NEW EVENT")
        title = prompt_validated("Event Title", lambda v: validate_non_empty(v, "Event title", 3, 80), error_printer=self.print_err)
        if title is None:
            return
        category = prompt_choice("Event Category", VALID_EVENT_CATEGORIES, default="Workshop", error_printer=self.print_err)
        if category is None:
            return
        event_date = prompt_validated("Event Date (YYYY-MM-DD)", lambda v: validate_date(v, "Event date"), error_printer=self.print_err)
        if event_date is None:
            return
        location = prompt_validated("Location", lambda v: validate_non_empty(v, "Location", 2, 60), error_printer=self.print_err)
        if location is None:
            return
        capacity = prompt_validated("Max Capacity", lambda v: validate_int(v, "Capacity", 1, 5000), default="40", error_printer=self.print_err)
        if capacity is None:
            return
        status = prompt_choice("Event Status", VALID_EVENT_STATUSES, default="Upcoming", error_printer=self.print_err)
        if status is None:
            return
        description = prompt_validated("Description (optional)", lambda v: sanitize_text(v)[:200], default="", error_printer=self.print_err)
        if description is None:
            return

        event = create_event(
            self.state,
            title=str(title),
            category=category,
            event_date=str(event_date),
            location=str(location),
            capacity=int(capacity),
            status=status,
            description=str(description),
        )
        save_state(self.state, self.data_dir)
        self.print_ok(f"Created event {event.event_id}: '{event.title}' on {event.event_date}.")

    def flow_record_attendance(self) -> None:
        self.print_header("RECORD EVENT ATTENDANCE")
        self.show_events_table()
        event_id = prompt_validated(
            "Event ID (e.g. EVT-206)",
            lambda v: validate_non_empty(v, "Event ID", 4, 15).upper(),
            error_printer=self.print_err,
        )
        if event_id is None:
            return
        if get_event_by_id(self.state, str(event_id)) is None:
            self.print_err(f"Event '{event_id}' not found.")
            return

        member_id = prompt_validated("Member ID (e.g. MEM-1008)", validate_member_id, error_printer=self.print_err)
        if member_id is None:
            return
        status = prompt_choice("Check-In Status", VALID_CHECKIN_STATUSES, default="Attended", error_printer=self.print_err)
        if status is None:
            return
        hours = prompt_validated(
            "Hours Credited",
            lambda v: validate_float(v, "Hours", 0.0, 48.0),
            default="2.0",
            error_printer=self.print_err,
        )
        if hours is None:
            return
        feedback = prompt_validated(
            "Feedback Score (1-5)",
            lambda v: validate_int(v, "Feedback score", 1, 5),
            default="5",
            error_printer=self.print_err,
        )
        if feedback is None:
            return

        try:
            rec = record_attendance(
                self.state,
                event_id=str(event_id),
                member_id=str(member_id),
                check_in_status=status,
                hours_credited=float(hours),
                feedback_score=int(feedback),
            )
            save_state(self.state, self.data_dir)
            self.print_ok(f"Saved attendance {rec.record_id}: {rec.member_id} -> {rec.event_id} ({rec.check_in_status}).")
        except ValidationError as err:
            self.print_err(str(err))

    def flow_view_event_roster(self) -> None:
        event_id = prompt_validated(
            "Event ID (e.g. EVT-203)",
            lambda v: validate_non_empty(v, "Event ID", 4, 15).upper(),
            error_printer=self.print_err,
        )
        if event_id is None:
            return
        try:
            roster = get_event_roster(self.state, str(event_id))
            event = get_event_by_id(self.state, str(event_id))
        except ValidationError as err:
            self.print_err(str(err))
            return

        headers = ("Record", "Member ID", "Full Name", "Status", "Hours", "Score")
        widths = (8, 9, 24, 10, 6, 5)
        rows = [
            (
                rec.record_id,
                rec.member_id,
                mem.full_name if mem else "(Removed)",
                rec.check_in_status,
                f"{rec.hours_credited:.1f}",
                str(rec.feedback_score),
            )
            for rec, mem in roster
        ]
        title = f"Roster for {event.event_id}: {event.title}" if event else "Event Roster"
        self.render_table(headers, rows, widths, title=title, paginate=True)

    # ------------------------------------------------------------------
    # 4. Membership Lists & Committees
    # ------------------------------------------------------------------

    def menu_lists(self) -> None:
        while True:
            self.print_header("MEMBERSHIP LISTS & COMMITTEES")
            print("  [1] View All Membership Lists")
            print("  [2] View Members in a Specific List")
            print("  [3] Create New Membership List")
            print("  [4] Add Member to List")
            print("  [5] Remove Member from List")
            print("  [0] Return to Main Menu")
            choice = sanitize_text(safe_read_line("\nLists option [0-5]: "))
            if choice == "1":
                headers = ("List ID", "Name", "Category", "Count", "Created", "Description")
                widths = (8, 26, 15, 5, 10, 24)
                rows = [
                    (lst.list_id, lst.name, lst.category, str(len(lst.member_ids)), lst.created_at, lst.description)
                    for lst in self.state.membership_lists
                ]
                self.render_table(headers, rows, widths, title="Membership Lists", paginate=True)
            elif choice == "2":
                list_id = prompt_validated("List ID (e.g. LST-301)", lambda v: validate_non_empty(v, "List ID", 4, 15).upper(), error_printer=self.print_err)
                if list_id is None:
                    continue
                try:
                    members = get_list_members(self.state, str(list_id))
                    lst = get_list_by_id(self.state, str(list_id))
                    self.render_members_table(members, title=f"List {lst.list_id}: {lst.name}" if lst else "List Members")
                except ValidationError as err:
                    self.print_err(str(err))
            elif choice == "3":
                name = prompt_validated("List Name", lambda v: validate_non_empty(v, "List name", 3, 50), error_printer=self.print_err)
                if name is None:
                    continue
                cat = prompt_validated("Category (e.g. Committee)", lambda v: validate_non_empty(v, "Category", 2, 30), default="Committee", error_printer=self.print_err)
                if cat is None:
                    continue
                desc = prompt_validated("Description", lambda v: sanitize_text(v)[:160], default="", error_printer=self.print_err)
                if desc is None:
                    continue
                try:
                    lst = create_membership_list(self.state, name=str(name), category=str(cat), description=str(desc))
                    save_state(self.state, self.data_dir)
                    self.print_ok(f"Created list {lst.list_id}: '{lst.name}'.")
                except ValidationError as err:
                    self.print_err(str(err))
            elif choice == "4":
                list_id = prompt_validated("List ID (e.g. LST-301)", lambda v: validate_non_empty(v, "List ID", 4, 15).upper(), error_printer=self.print_err)
                if list_id is None:
                    continue
                member_id = prompt_validated("Member ID (e.g. MEM-1008)", validate_member_id, error_printer=self.print_err)
                if member_id is None:
                    continue
                try:
                    lst = add_member_to_list(self.state, str(list_id), str(member_id))
                    save_state(self.state, self.data_dir)
                    self.print_ok(f"Added {member_id} to '{lst.name}'.")
                except ValidationError as err:
                    self.print_err(str(err))
            elif choice == "5":
                list_id = prompt_validated("List ID", lambda v: validate_non_empty(v, "List ID", 4, 15).upper(), error_printer=self.print_err)
                if list_id is None:
                    continue
                member_id = prompt_validated("Member ID", validate_member_id, error_printer=self.print_err)
                if member_id is None:
                    continue
                try:
                    lst = remove_member_from_list(self.state, str(list_id), str(member_id))
                    save_state(self.state, self.data_dir)
                    self.print_ok(f"Removed {member_id} from '{lst.name}'.")
                except ValidationError as err:
                    self.print_err(str(err))
            elif choice == "0":
                return
            else:
                self.print_err(f"Invalid option '{choice}'. Choose 0-5.")

    # ------------------------------------------------------------------
    # 5. Executive Summary & Trends
    # ------------------------------------------------------------------

    def menu_summary(self) -> None:
        self.print_header("EXECUTIVE SUMMARY & ANALYTICS")
        summary = generate_executive_summary(self.state)

        health = summary["health_indicator"]
        badge = self.palette.green(health) if health == "HEALTHY" else self.palette.yellow(health)
        print(f"  Organization : {self.palette.bold(summary['club_name'])}")
        print(f"  Generated At : {summary['generated_at']}   |   Health Indicator: {badge}")

        kpi_rows = [
            ("Total Members", str(summary["total_members"])),
            ("Active Members", f"{summary['active_members']} ({summary['retention_rate_pct']}%)"),
            ("Dues Collected", f"${summary['collected_dues']:.2f}"),
            ("Outstanding Dues", f"${summary['outstanding_dues']:.2f}"),
            ("Dues Compliance Rate", f"{summary['dues_compliance_pct']}%"),
            ("Total Club Events", str(summary["total_events"])),
            ("Avg Events Attended / Member", str(summary["avg_events_per_member"])),
            ("Total Credited Hours", f"{summary['total_hours_credited']} hrs"),
            ("Average Event Feedback", f"{summary['avg_event_feedback']} / 5.0"),
        ]
        self.render_table(("Key Performance Indicator", "Value"), kpi_rows, (34, 28), title="Club KPI Overview", paginate=False)

        # ASCII distribution chart for Tiers
        print(f"\n{self.palette.bold('Membership Tier Distribution (ASCII Chart)')}")
        total = max(1, summary["total_members"])
        for tier in VALID_TIERS:
            count = summary["tier_breakdown"].get(tier, 0)
            bar_len = int((count / total) * 30)
            bar = "#" * bar_len
            pct = (count / total) * 100.0
            print(f"  {tier:<10} | {bar:<30} | {count:>2} ({pct:5.1f}%)")

        if summary["monthly_join_trend"]:
            print(f"\n{self.palette.bold('Recent Monthly Join Trend')}")
            max_join = max((c for _, c in summary["monthly_join_trend"]), default=1)
            for month, count in summary["monthly_join_trend"]:
                bar = "=" * max(1, int((count / max_join) * 24))
                print(f"  {month} | {bar:<24} | {count} join(s)")

        top_rows = [
            (m["member_id"], m["full_name"], m["role"], m["tier"], str(m["events_attended"]))
            for m in summary["top_members"]
        ]
        self.render_table(
            ("ID", "Top Engaged Member", "Role", "Tier", "Events"),
            top_rows,
            (8, 24, 15, 9, 6),
            title="Top 5 Most Active Members",
            paginate=False,
        )
        self.pause()

    # ------------------------------------------------------------------
    # 6. Threshold Warnings & Anomaly Scan
    # ------------------------------------------------------------------

    def menu_warnings(self) -> None:
        self.print_header("THRESHOLD WARNING INDICATORS")
        warnings = evaluate_threshold_warnings(self.state)
        if not warnings:
            self.print_ok("No overdue renewals, capacity breaches, or anomalies detected.")
            self.pause()
            return

        rows = [(w.severity, w.code, f"{w.entity_type}:{w.entity_id}", w.message) for w in warnings]
        self.render_table(
            ("Severity", "Code", "Target", "Details"),
            rows,
            (8, 22, 14, 52),
            title="Automated Threshold Alerts",
            paginate=True,
        )
        self.pause()

    # ------------------------------------------------------------------
    # 7. Bulk CSV Dataset Import
    # ------------------------------------------------------------------

    def menu_bulk_import(self) -> None:
        self.print_header("BULK CSV DATASET IMPORT")
        sample_hint = str(self.data_dir / "sample_bulk_import.csv")
        print(f"  Sample legacy CSV available at: {self.palette.cyan(sample_hint)}")
        path_val = prompt_validated(
            "CSV file path to import",
            lambda v: validate_non_empty(v, "File path", 1, 200),
            default=sample_hint,
            error_printer=self.print_err,
        )
        if path_val is None:
            return

        try:
            raw_rows = read_bulk_csv(str(path_val))
        except StorageError as err:
            self.print_err(str(err))
            self.pause()
            return

        result = import_members_from_rows(self.state, raw_rows)
        if result["imported_count"] > 0:
            save_state(self.state, self.data_dir)

        print(
            f"\n  Import Summary: Total={result['total_rows']} | "
            f"{self.palette.green('Imported=' + str(result['imported_count']))} | "
            f"{self.palette.red('Failed=' + str(result['failed_count']))}"
        )

        diag_rows = [
            (
                str(item["row_number"]),
                item["status"],
                item["name"],
                item.get("member_id", "-") if item["status"] == "IMPORTED" else "; ".join(item["errors"]),
            )
            for item in result["diagnostics"]
        ]
        self.render_table(
            ("Row", "Status", "Member Name", "Assigned ID / Validation Errors"),
            diag_rows,
            (4, 8, 20, 56),
            title="Row-by-Row Import Diagnostics",
            paginate=True,
        )
        self.pause()

    # ------------------------------------------------------------------
    # 8. Multi-Format Report Exports
    # ------------------------------------------------------------------

    def menu_exports(self) -> None:
        while True:
            self.print_header("EXPORT REPORTS")
            print("  [1] Export Markdown Executive Report (.md)")
            print("  [2] Export Plain-Text Audit Log (.txt)")
            print("  [3] Export Standardized CSV Reports (.csv)")
            print("  [4] Export ALL Formats & Preview Summary")
            print("  [0] Return to Main Menu")
            choice = sanitize_text(safe_read_line("\nExport option [0-4]: "))
            if choice == "1":
                path = export_markdown_report(self.state, self.export_dir)
                self.print_ok(f"Markdown report generated at '{path}'.")
                self._preview_file(path, max_lines=22)
            elif choice == "2":
                path = export_audit_log(self.state, self.export_dir)
                self.print_ok(f"Plain-text audit log generated at '{path}'.")
                self._preview_file(path, max_lines=22)
            elif choice == "3":
                members_csv, metrics_csv = export_csv_reports(self.state, self.export_dir)
                self.print_ok(f"CSV reports generated at '{members_csv}' and '{metrics_csv}'.")
                self._preview_file(metrics_csv, max_lines=18)
            elif choice == "4":
                paths = export_all_reports(self.state, self.export_dir)
                self.print_ok("Generated all report formats:")
                for label, p in paths.items():
                    print(f"    - {label:<12}: {p}")
                self._preview_file(paths["markdown"], max_lines=20)
            elif choice == "0":
                return
            else:
                self.print_err(f"Invalid option '{choice}'. Choose 0-4.")

    def _preview_file(self, path: Path, max_lines: int = 20) -> None:
        print(f"\n{self.palette.dim('--- Preview: ' + str(path) + ' ---')}")
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
            for line in lines[:max_lines]:
                print(f"  {line}")
            if len(lines) > max_lines:
                print(self.palette.dim(f"  ... ({len(lines) - max_lines} more lines in file)"))
        except OSError as exc:
            self.print_err(f"Could not preview file: {exc}")

    # ------------------------------------------------------------------
    # 9. Storage Integrity & Reload
    # ------------------------------------------------------------------

    def menu_storage(self) -> None:
        self.print_header("STORAGE & PERSISTENCE CHECK")
        csv_path, json_path = save_state(self.state, self.data_dir)
        self.print_ok(f"Saved state to '{csv_path}' and '{json_path}'.")
        reloaded = load_state(self.data_dir)
        self.state = reloaded
        self.print_ok(
            f"Reloaded {len(self.state.members)} members, {len(self.state.events)} events, "
            f"{len(self.state.attendance)} attendance logs, {len(self.state.membership_lists)} lists."
        )
        if self.state.startup_notices:
            for note in self.state.startup_notices:
                self.print_warn(note)
            self.state.startup_notices.clear()
        self.pause()
