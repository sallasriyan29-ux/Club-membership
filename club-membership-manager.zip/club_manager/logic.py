"""Pure business logic engine for Club Membership Manager.

Decoupled from terminal I/O and local file storage so every rule,
calculation, search, warning check, and bulk import is unit-testable.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
from typing import Any, Optional

from club_manager.models import (
    AttendanceRecord,
    AuditEntry,
    ClubEvent,
    ClubState,
    Member,
    MembershipList,
    TIER_DUES_DEFAULTS,
    ThresholdWarning,
)
from club_manager.validators import ValidationError, validate_member_row


def _now_iso() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def append_audit(state: ClubState, action: str, entity_id: str, details: str) -> None:
    state.audit_log.append(
        AuditEntry(
            timestamp=_now_iso(),
            action=action,
            entity_id=entity_id,
            details=details,
        )
    )


# ---------------------------------------------------------------------------
# ID Generators
# ---------------------------------------------------------------------------

def generate_member_id(state: ClubState) -> str:
    existing_nums = []
    for m in state.members:
        if m.member_id.startswith("MEM-") and m.member_id[4:].isdigit():
            existing_nums.append(int(m.member_id[4:]))
    next_num = max(existing_nums, default=1000) + 1
    return f"MEM-{next_num:04d}"


def generate_event_id(state: ClubState) -> str:
    existing_nums = []
    for ev in state.events:
        if ev.event_id.startswith("EVT-") and ev.event_id[4:].isdigit():
            existing_nums.append(int(ev.event_id[4:]))
    next_num = max(existing_nums, default=200) + 1
    return f"EVT-{next_num:03d}"


def generate_attendance_id(state: ClubState) -> str:
    existing_nums = []
    for rec in state.attendance:
        if rec.record_id.startswith("ATT-") and rec.record_id[4:].isdigit():
            existing_nums.append(int(rec.record_id[4:]))
    next_num = max(existing_nums, default=5000) + 1
    return f"ATT-{next_num:04d}"


def generate_list_id(state: ClubState) -> str:
    existing_nums = []
    for lst in state.membership_lists:
        if lst.list_id.startswith("LST-") and lst.list_id[4:].isdigit():
            existing_nums.append(int(lst.list_id[4:]))
    next_num = max(existing_nums, default=300) + 1
    return f"LST-{next_num:03d}"


# ---------------------------------------------------------------------------
# Member Operations
# ---------------------------------------------------------------------------

def get_member_by_id(state: ClubState, member_id: str) -> Optional[Member]:
    target = member_id.strip().upper()
    for m in state.members:
        if m.member_id.upper() == target:
            return m
    return None


def add_member(
    state: ClubState,
    *,
    full_name: str,
    email: str,
    student_id: str,
    role: str = "Member",
    membership_tier: str = "Standard",
    status: str = "Active",
    dues_paid: bool = False,
    dues_amount: Optional[float] = None,
    join_date: Optional[str] = None,
    renewal_due_date: Optional[str] = None,
    events_attended: int = 0,
    notes: str = "",
    member_id: Optional[str] = None,
) -> Member:
    norm_email = email.strip().lower()
    norm_sid = student_id.strip().upper()

    for existing in state.members:
        if existing.email.lower() == norm_email:
            raise ValidationError(f"A member with email '{norm_email}' already exists ({existing.member_id}).")
        if existing.student_id.upper() == norm_sid:
            raise ValidationError(f"A member with Student ID '{norm_sid}' already exists ({existing.member_id}).")

    assigned_id = member_id or generate_member_id(state)
    if get_member_by_id(state, assigned_id) is not None:
        raise ValidationError(f"Member ID '{assigned_id}' already exists.")

    today = date.today()
    resolved_join = join_date or today.isoformat()
    resolved_renewal = renewal_due_date or (date.fromisoformat(resolved_join) + timedelta(days=365)).isoformat()
    resolved_dues = dues_amount if dues_amount is not None else TIER_DUES_DEFAULTS.get(membership_tier, 25.0)

    member = Member(
        member_id=assigned_id,
        full_name=full_name.strip(),
        email=norm_email,
        student_id=norm_sid,
        role=role,
        membership_tier=membership_tier,
        status=status,
        dues_paid=dues_paid,
        dues_amount=round(float(resolved_dues), 2),
        join_date=resolved_join,
        renewal_due_date=resolved_renewal,
        events_attended=int(events_attended),
        notes=notes.strip(),
    )
    state.members.append(member)
    append_audit(state, "ADD_MEMBER", member.member_id, f"Added {member.full_name} ({member.membership_tier}, {member.status})")
    return member


def update_member(
    state: ClubState,
    member_id: str,
    **updates: Any,
) -> Member:
    member = get_member_by_id(state, member_id)
    if member is None:
        raise ValidationError(f"Member '{member_id}' not found.")

    if "email" in updates and updates["email"] is not None:
        new_email = str(updates["email"]).strip().lower()
        for other in state.members:
            if other.member_id != member.member_id and other.email.lower() == new_email:
                raise ValidationError(f"Email '{new_email}' is already assigned to {other.member_id}.")
        member.email = new_email

    if "student_id" in updates and updates["student_id"] is not None:
        new_sid = str(updates["student_id"]).strip().upper()
        for other in state.members:
            if other.member_id != member.member_id and other.student_id.upper() == new_sid:
                raise ValidationError(f"Student ID '{new_sid}' is already assigned to {other.member_id}.")
        member.student_id = new_sid

    for field_name in ("full_name", "role", "membership_tier", "status", "renewal_due_date", "notes"):
        if field_name in updates and updates[field_name] is not None:
            setattr(member, field_name, str(updates[field_name]).strip())

    if "dues_paid" in updates and updates["dues_paid"] is not None:
        member.dues_paid = bool(updates["dues_paid"])

    if "dues_amount" in updates and updates["dues_amount"] is not None:
        member.dues_amount = round(float(updates["dues_amount"]), 2)

    append_audit(state, "UPDATE_MEMBER", member.member_id, f"Updated profile for {member.full_name}")
    return member


def record_dues_payment(
    state: ClubState,
    member_id: str,
    amount: Optional[float] = None,
    extend_days: int = 365,
) -> Member:
    member = get_member_by_id(state, member_id)
    if member is None:
        raise ValidationError(f"Member '{member_id}' not found.")

    if amount is not None:
        member.dues_amount = round(float(amount), 2)
    member.dues_paid = True
    if member.status == "Pending":
        member.status = "Active"

    base_date = date.today()
    try:
        current_due = date.fromisoformat(member.renewal_due_date)
        if current_due > base_date:
            base_date = current_due
    except ValueError:
        pass
    member.renewal_due_date = (base_date + timedelta(days=extend_days)).isoformat()
    append_audit(
        state,
        "RENEW_DUES",
        member.member_id,
        f"Recorded ${member.dues_amount:.2f} dues payment; next renewal {member.renewal_due_date}",
    )
    return member


def remove_member(state: ClubState, member_id: str) -> Member:
    member = get_member_by_id(state, member_id)
    if member is None:
        raise ValidationError(f"Member '{member_id}' not found.")

    state.members = [m for m in state.members if m.member_id != member.member_id]
    state.attendance = [a for a in state.attendance if a.member_id != member.member_id]
    for lst in state.membership_lists:
        if member.member_id in lst.member_ids:
            lst.member_ids = [mid for mid in lst.member_ids if mid != member.member_id]

    append_audit(state, "REMOVE_MEMBER", member.member_id, f"Removed member {member.full_name}")
    return member


# ---------------------------------------------------------------------------
# Event Participation Operations
# ---------------------------------------------------------------------------

def get_event_by_id(state: ClubState, event_id: str) -> Optional[ClubEvent]:
    target = event_id.strip().upper()
    for ev in state.events:
        if ev.event_id.upper() == target:
            return ev
    return None


def create_event(
    state: ClubState,
    *,
    title: str,
    category: str,
    event_date: str,
    location: str,
    capacity: int,
    status: str = "Upcoming",
    description: str = "",
) -> ClubEvent:
    event = ClubEvent(
        event_id=generate_event_id(state),
        title=title.strip(),
        category=category,
        event_date=event_date,
        location=location.strip(),
        capacity=int(capacity),
        status=status,
        description=description.strip(),
    )
    state.events.append(event)
    append_audit(state, "CREATE_EVENT", event.event_id, f"Created event '{event.title}' on {event.event_date}")
    return event


def get_event_roster(state: ClubState, event_id: str) -> list[tuple[AttendanceRecord, Optional[Member]]]:
    event = get_event_by_id(state, event_id)
    if event is None:
        raise ValidationError(f"Event '{event_id}' not found.")
    member_map = {m.member_id: m for m in state.members}
    records = [a for a in state.attendance if a.event_id == event.event_id]
    return [(rec, member_map.get(rec.member_id)) for rec in records]


def record_attendance(
    state: ClubState,
    *,
    event_id: str,
    member_id: str,
    check_in_status: str = "Attended",
    hours_credited: float = 2.0,
    feedback_score: int = 5,
) -> AttendanceRecord:
    event = get_event_by_id(state, event_id)
    if event is None:
        raise ValidationError(f"Event '{event_id}' not found.")
    member = get_member_by_id(state, member_id)
    if member is None:
        raise ValidationError(f"Member '{member_id}' not found.")

    if event.status == "Cancelled":
        raise ValidationError(f"Cannot record attendance for cancelled event {event.event_id}.")

    existing = next(
        (a for a in state.attendance if a.event_id == event.event_id and a.member_id == member.member_id),
        None,
    )

    active_attendees = sum(
        1
        for a in state.attendance
        if a.event_id == event.event_id and a.check_in_status in ("Attended", "RSVP")
    )

    if existing is None and check_in_status in ("Attended", "RSVP") and active_attendees >= event.capacity:
        raise ValidationError(
            f"Event {event.event_id} ('{event.title}') is at full capacity ({event.capacity}/{event.capacity})."
        )

    if existing is not None:
        was_attended = existing.check_in_status == "Attended"
        existing.check_in_status = check_in_status
        existing.hours_credited = round(float(hours_credited), 2) if check_in_status == "Attended" else 0.0
        existing.feedback_score = int(feedback_score)
        existing.recorded_at = _now_iso()
        if not was_attended and check_in_status == "Attended":
            member.events_attended += 1
        elif was_attended and check_in_status != "Attended" and member.events_attended > 0:
            member.events_attended -= 1
        append_audit(
            state,
            "UPDATE_ATTENDANCE",
            existing.record_id,
            f"Updated {member.member_id} @ {event.event_id} -> {check_in_status}",
        )
        return existing

    rec = AttendanceRecord(
        record_id=generate_attendance_id(state),
        event_id=event.event_id,
        member_id=member.member_id,
        check_in_status=check_in_status,
        hours_credited=round(float(hours_credited), 2) if check_in_status == "Attended" else 0.0,
        recorded_at=_now_iso(),
        feedback_score=int(feedback_score),
    )
    state.attendance.append(rec)
    if check_in_status == "Attended":
        member.events_attended += 1
    append_audit(
        state,
        "RECORD_ATTENDANCE",
        rec.record_id,
        f"Recorded {member.member_id} @ {event.event_id} ({check_in_status})",
    )
    return rec


# ---------------------------------------------------------------------------
# Membership List Operations
# ---------------------------------------------------------------------------

def get_list_by_id(state: ClubState, list_id: str) -> Optional[MembershipList]:
    target = list_id.strip().upper()
    for lst in state.membership_lists:
        if lst.list_id.upper() == target:
            return lst
    return None


def create_membership_list(
    state: ClubState,
    *,
    name: str,
    category: str,
    description: str = "",
) -> MembershipList:
    clean_name = name.strip()
    for existing in state.membership_lists:
        if existing.name.lower() == clean_name.lower():
            raise ValidationError(f"Membership list '{clean_name}' already exists ({existing.list_id}).")
    new_list = MembershipList(
        list_id=generate_list_id(state),
        name=clean_name,
        category=category.strip(),
        description=description.strip(),
        member_ids=[],
        created_at=date.today().isoformat(),
    )
    state.membership_lists.append(new_list)
    append_audit(state, "CREATE_LIST", new_list.list_id, f"Created membership list '{new_list.name}'")
    return new_list


def add_member_to_list(state: ClubState, list_id: str, member_id: str) -> MembershipList:
    lst = get_list_by_id(state, list_id)
    if lst is None:
        raise ValidationError(f"Membership list '{list_id}' not found.")
    member = get_member_by_id(state, member_id)
    if member is None:
        raise ValidationError(f"Member '{member_id}' not found.")
    if member.member_id in lst.member_ids:
        raise ValidationError(f"{member.member_id} ({member.full_name}) is already in '{lst.name}'.")
    lst.member_ids.append(member.member_id)
    append_audit(state, "ADD_TO_LIST", lst.list_id, f"Added {member.member_id} to '{lst.name}'")
    return lst


def remove_member_from_list(state: ClubState, list_id: str, member_id: str) -> MembershipList:
    lst = get_list_by_id(state, list_id)
    if lst is None:
        raise ValidationError(f"Membership list '{list_id}' not found.")
    target = member_id.strip().upper()
    if target not in lst.member_ids:
        raise ValidationError(f"Member '{target}' is not in '{lst.name}'.")
    lst.member_ids = [mid for mid in lst.member_ids if mid != target]
    append_audit(state, "REMOVE_FROM_LIST", lst.list_id, f"Removed {target} from '{lst.name}'")
    return lst


def get_list_members(state: ClubState, list_id: str) -> list[Member]:
    lst = get_list_by_id(state, list_id)
    if lst is None:
        raise ValidationError(f"Membership list '{list_id}' not found.")
    member_map = {m.member_id: m for m in state.members}
    return [member_map[mid] for mid in lst.member_ids if mid in member_map]


# ---------------------------------------------------------------------------
# Record Query & Search
# ---------------------------------------------------------------------------

def search_members(state: ClubState, keyword: str) -> list[Member]:
    q = keyword.strip().lower()
    if not q:
        return list(state.members)
    matches = []
    for m in state.members:
        haystack = " ".join(
            [m.member_id, m.full_name, m.email, m.student_id, m.role, m.membership_tier, m.status, m.notes]
        ).lower()
        if q in haystack:
            matches.append(m)
    return matches


def filter_members(
    state: ClubState,
    *,
    status: Optional[str] = None,
    membership_tier: Optional[str] = None,
    role: Optional[str] = None,
    dues_paid: Optional[bool] = None,
    list_id: Optional[str] = None,
) -> list[Member]:
    results = list(state.members)
    if list_id:
        lst = get_list_by_id(state, list_id)
        if lst is None:
            return []
        allowed_ids = set(lst.member_ids)
        results = [m for m in results if m.member_id in allowed_ids]
    if status:
        results = [m for m in results if m.status.lower() == status.strip().lower()]
    if membership_tier:
        results = [m for m in results if m.membership_tier.lower() == membership_tier.strip().lower()]
    if role:
        results = [m for m in results if m.role.lower() == role.strip().lower()]
    if dues_paid is not None:
        results = [m for m in results if m.dues_paid is dues_paid]
    return results


# ---------------------------------------------------------------------------
# Threshold Warnings & Anomaly Detection
# ---------------------------------------------------------------------------

def evaluate_threshold_warnings(
    state: ClubState,
    reference_date: Optional[date] = None,
) -> list[ThresholdWarning]:
    ref = reference_date or date.today()
    warnings: list[ThresholdWarning] = []

    seen_emails: dict[str, str] = {}
    seen_sids: dict[str, str] = {}

    for m in state.members:
        # Duplicate checks
        em = m.email.lower()
        if em in seen_emails:
            warnings.append(
                ThresholdWarning(
                    severity="CRITICAL",
                    code="DUPLICATE_EMAIL",
                    entity_type="Member",
                    entity_id=m.member_id,
                    message=f"Duplicate email '{em}' shared between {seen_emails[em]} and {m.member_id}.",
                )
            )
        else:
            seen_emails[em] = m.member_id

        sid = m.student_id.upper()
        if sid in seen_sids:
            warnings.append(
                ThresholdWarning(
                    severity="CRITICAL",
                    code="DUPLICATE_STUDENT_ID",
                    entity_type="Member",
                    entity_id=m.member_id,
                    message=f"Duplicate Student ID '{sid}' shared between {seen_sids[sid]} and {m.member_id}.",
                )
            )
        else:
            seen_sids[sid] = m.member_id

        # Overdue renewal check
        if m.status in ("Active", "Pending") and m.renewal_due_date:
            try:
                due_dt = date.fromisoformat(m.renewal_due_date)
                if due_dt < ref:
                    days_over = (ref - due_dt).days
                    severity = "CRITICAL" if days_over > 30 else "WARNING"
                    warnings.append(
                        ThresholdWarning(
                            severity=severity,
                            code="OVERDUE_RENEWAL",
                            entity_type="Member",
                            entity_id=m.member_id,
                            message=f"{m.full_name} ({m.member_id}) renewal overdue by {days_over} day(s) (due {m.renewal_due_date}).",
                        )
                    )
            except ValueError:
                warnings.append(
                    ThresholdWarning(
                        severity="WARNING",
                        code="INVALID_RENEWAL_DATE",
                        entity_type="Member",
                        entity_id=m.member_id,
                        message=f"{m.full_name} ({m.member_id}) has invalid renewal date '{m.renewal_due_date}'.",
                    )
                )

        # Active unpaid dues check
        if m.status == "Active" and not m.dues_paid and m.dues_amount > 0:
            warnings.append(
                ThresholdWarning(
                    severity="WARNING",
                    code="UNPAID_ACTIVE_DUES",
                    entity_type="Member",
                    entity_id=m.member_id,
                    message=f"Active member {m.full_name} ({m.member_id}) has unpaid dues (${m.dues_amount:.2f}).",
                )
            )

        # Low engagement risk check
        if m.status == "Active" and m.events_attended == 0 and m.join_date:
            try:
                join_dt = date.fromisoformat(m.join_date)
                if (ref - join_dt).days > 60:
                    warnings.append(
                        ThresholdWarning(
                            severity="INFO",
                            code="ZERO_ENGAGEMENT",
                            entity_type="Member",
                            entity_id=m.member_id,
                            message=f"{m.full_name} ({m.member_id}) joined {m.join_date} with 0 events attended.",
                        )
                    )
            except ValueError:
                pass

    # Event capacity & anomaly checks
    for ev in state.events:
        if ev.status == "Cancelled":
            continue
        reg_count = sum(
            1
            for a in state.attendance
            if a.event_id == ev.event_id and a.check_in_status in ("Attended", "RSVP")
        )
        if ev.capacity <= 0:
            warnings.append(
                ThresholdWarning(
                    severity="CRITICAL",
                    code="INVALID_EVENT_CAPACITY",
                    entity_type="Event",
                    entity_id=ev.event_id,
                    message=f"Event '{ev.title}' ({ev.event_id}) has non-positive capacity ({ev.capacity}).",
                )
            )
            continue
        ratio = reg_count / ev.capacity
        if reg_count > ev.capacity:
            warnings.append(
                ThresholdWarning(
                    severity="CRITICAL",
                    code="EVENT_OVER_CAPACITY",
                    entity_type="Event",
                    entity_id=ev.event_id,
                    message=f"Event '{ev.title}' ({ev.event_id}) exceeds capacity ({reg_count}/{ev.capacity}).",
                )
            )
        elif ratio >= 0.90 and ev.status in ("Upcoming", "Ongoing"):
            warnings.append(
                ThresholdWarning(
                    severity="WARNING",
                    code="EVENT_NEAR_CAPACITY",
                    entity_type="Event",
                    entity_id=ev.event_id,
                    message=f"Event '{ev.title}' ({ev.event_id}) is at {ratio * 100:.0f}% capacity ({reg_count}/{ev.capacity}).",
                )
            )

    severity_rank = {"CRITICAL": 0, "WARNING": 1, "INFO": 2}
    warnings.sort(key=lambda w: (severity_rank.get(w.severity, 9), w.entity_id))
    return warnings


# ---------------------------------------------------------------------------
# Executive Summary Generation
# ---------------------------------------------------------------------------

def generate_executive_summary(
    state: ClubState,
    reference_date: Optional[date] = None,
) -> dict[str, Any]:
    total_members = len(state.members)
    status_counts = Counter(m.status for m in state.members)
    tier_counts = Counter(m.membership_tier for m in state.members)
    role_counts = Counter(m.role for m in state.members)

    paid_members = [m for m in state.members if m.dues_paid]
    unpaid_members = [m for m in state.members if not m.dues_paid and m.dues_amount > 0]
    collected_dues = round(sum(m.dues_amount for m in paid_members), 2)
    outstanding_dues = round(sum(m.dues_amount for m in unpaid_members), 2)
    billable_count = sum(1 for m in state.members if m.dues_amount > 0)
    dues_compliance_pct = round((len([m for m in paid_members if m.dues_amount > 0]) / billable_count * 100.0), 1) if billable_count else 100.0

    total_events_attended_sum = sum(m.events_attended for m in state.members)
    avg_events_per_member = round(total_events_attended_sum / total_members, 2) if total_members else 0.0

    attended_records = [a for a in state.attendance if a.check_in_status == "Attended"]
    total_volunteer_hours = round(sum(a.hours_credited for a in attended_records), 1)
    feedback_scores = [a.feedback_score for a in attended_records if 1 <= a.feedback_score <= 5]
    avg_feedback = round(sum(feedback_scores) / len(feedback_scores), 2) if feedback_scores else 0.0

    # Monthly join trend (YYYY-MM)
    monthly_joins: dict[str, int] = defaultdict(int)
    for m in state.members:
        if len(m.join_date) >= 7:
            monthly_joins[m.join_date[:7]] += 1
    sorted_trends = sorted(monthly_joins.items())[-6:]

    top_members = sorted(state.members, key=lambda m: (-m.events_attended, m.full_name))[:5]
    warnings = evaluate_threshold_warnings(state, reference_date=reference_date)
    warning_counts = Counter(w.severity for w in warnings)

    active_count = status_counts.get("Active", 0)
    retention_pct = round((active_count / total_members * 100.0), 1) if total_members else 0.0

    health_indicator = "HEALTHY"
    if warning_counts.get("CRITICAL", 0) > 0 or dues_compliance_pct < 65.0:
        health_indicator = "ATTENTION REQUIRED"
    elif warning_counts.get("WARNING", 0) > 3 or dues_compliance_pct < 85.0:
        health_indicator = "MONITOR"

    return {
        "club_name": state.club_name,
        "generated_at": _now_iso(),
        "total_members": total_members,
        "active_members": active_count,
        "retention_rate_pct": retention_pct,
        "total_events": len(state.events),
        "total_attendance_records": len(state.attendance),
        "total_lists": len(state.membership_lists),
        "collected_dues": collected_dues,
        "outstanding_dues": outstanding_dues,
        "dues_compliance_pct": dues_compliance_pct,
        "avg_events_per_member": avg_events_per_member,
        "total_hours_credited": total_volunteer_hours,
        "avg_event_feedback": avg_feedback,
        "status_breakdown": dict(status_counts),
        "tier_breakdown": dict(tier_counts),
        "role_breakdown": dict(role_counts),
        "monthly_join_trend": sorted_trends,
        "top_members": [
            {
                "member_id": m.member_id,
                "full_name": m.full_name,
                "role": m.role,
                "tier": m.membership_tier,
                "events_attended": m.events_attended,
            }
            for m in top_members
        ],
        "warning_counts": dict(warning_counts),
        "health_indicator": health_indicator,
    }


# ---------------------------------------------------------------------------
# Bulk CSV Dataset Import
# ---------------------------------------------------------------------------

def import_members_from_rows(
    state: ClubState,
    rows: list[dict[str, str]],
) -> dict[str, Any]:
    """Validate and ingest bulk member rows with row-by-row diagnostics."""
    imported: list[Member] = []
    diagnostics: list[dict[str, Any]] = []

    existing_emails = {m.email.lower() for m in state.members}
    existing_sids = {m.student_id.upper() for m in state.members}
    existing_ids = {m.member_id.upper() for m in state.members}

    for idx, raw_row in enumerate(rows, start=2):  # Row 1 is CSV header
        cleaned, errors = validate_member_row(raw_row, require_member_id=False)
        if not errors:
            email = str(cleaned["email"]).lower()
            sid = str(cleaned["student_id"]).upper()
            cand_id = str(cleaned.get("member_id") or "").upper()
            if email in existing_emails:
                errors.append(f"Duplicate email '{email}' already exists in directory.")
            if sid in existing_sids:
                errors.append(f"Duplicate Student ID '{sid}' already exists in directory.")
            if cand_id and cand_id in existing_ids:
                errors.append(f"Duplicate Member ID '{cand_id}' already exists in directory.")

        if errors:
            diagnostics.append(
                {
                    "row_number": idx,
                    "status": "FAILED",
                    "name": raw_row.get("full_name", "").strip() or "(blank)",
                    "errors": errors,
                }
            )
            continue

        assigned_id = str(cleaned.get("member_id") or "") or generate_member_id(state)
        member = Member(
            member_id=assigned_id,
            full_name=str(cleaned["full_name"]),
            email=str(cleaned["email"]),
            student_id=str(cleaned["student_id"]),
            role=str(cleaned["role"]),
            membership_tier=str(cleaned["membership_tier"]),
            status=str(cleaned["status"]),
            dues_paid=bool(cleaned["dues_paid"]),
            dues_amount=float(cleaned["dues_amount"]),
            join_date=str(cleaned["join_date"]),
            renewal_due_date=str(cleaned["renewal_due_date"]),
            events_attended=int(cleaned["events_attended"]),
            notes=str(cleaned["notes"]),
        )
        state.members.append(member)
        existing_emails.add(member.email.lower())
        existing_sids.add(member.student_id.upper())
        existing_ids.add(member.member_id.upper())
        imported.append(member)
        diagnostics.append(
            {
                "row_number": idx,
                "status": "IMPORTED",
                "name": member.full_name,
                "member_id": member.member_id,
                "errors": [],
            }
        )

    if imported:
        append_audit(
            state,
            "BULK_IMPORT",
            "CSV_BATCH",
            f"Imported {len(imported)} valid member(s); rejected {len(rows) - len(imported)} invalid row(s)",
        )

    return {
        "total_rows": len(rows),
        "imported_count": len(imported),
        "failed_count": len(rows) - len(imported),
        "imported_members": imported,
        "diagnostics": diagnostics,
    }
