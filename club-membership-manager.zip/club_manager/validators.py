"""Defensive input validation, sanitization, and safe console prompt wrappers."""

from __future__ import annotations

import re
import sys
from datetime import date, datetime
from typing import Callable, Iterable, Optional

from club_manager.models import (
    VALID_CHECKIN_STATUSES,
    VALID_EVENT_CATEGORIES,
    VALID_EVENT_STATUSES,
    VALID_MEMBER_STATUSES,
    VALID_ROLES,
    VALID_TIERS,
)

EMAIL_REGEX = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
STUDENT_ID_REGEX = re.compile(r"^[A-Za-z]{2,4}-?\d{4,8}$")
MEMBER_ID_REGEX = re.compile(r"^MEM-\d{4,6}$")
NAME_REGEX = re.compile(r"^[A-Za-z][A-Za-z\s'\-\.]{1,78}$")


class ValidationError(ValueError):
    """Raised when an input fails domain or type validation."""


def sanitize_text(raw: str, collapse_whitespace: bool = True) -> str:
    """Strip control characters, leading/trailing whitespace, and optionally collapse spaces."""
    if raw is None:
        return ""
    cleaned = "".join(ch for ch in str(raw) if ch.isprintable())
    cleaned = cleaned.strip()
    if collapse_whitespace:
        cleaned = re.sub(r"\s+", " ", cleaned)
    return cleaned


def validate_non_empty(value: str, field_name: str, min_len: int = 1, max_len: int = 120) -> str:
    cleaned = sanitize_text(value)
    if not cleaned:
        raise ValidationError(f"{field_name} cannot be blank.")
    if len(cleaned) < min_len:
        raise ValidationError(f"{field_name} must be at least {min_len} characters.")
    if len(cleaned) > max_len:
        raise ValidationError(f"{field_name} cannot exceed {max_len} characters.")
    return cleaned


def validate_full_name(value: str) -> str:
    cleaned = validate_non_empty(value, "Full name", min_len=2, max_len=80)
    if not NAME_REGEX.match(cleaned):
        raise ValidationError(
            "Full name must start with a letter and contain only letters, spaces, hyphens, apostrophes, or periods."
        )
    return cleaned


def validate_email(value: str) -> str:
    cleaned = sanitize_text(value).lower()
    if not cleaned:
        raise ValidationError("Email address cannot be blank.")
    if not EMAIL_REGEX.match(cleaned):
        raise ValidationError("Invalid email format (expected e.g. alex.chen@campus.edu).")
    return cleaned


def validate_student_id(value: str) -> str:
    cleaned = sanitize_text(value).upper()
    if not cleaned:
        raise ValidationError("Student ID cannot be blank.")
    if not STUDENT_ID_REGEX.match(cleaned):
        raise ValidationError("Student ID must match format like STU-1042 or CS202512 (2-4 letters + 4-8 digits).")
    return cleaned


def validate_member_id(value: str) -> str:
    cleaned = sanitize_text(value).upper()
    if not MEMBER_ID_REGEX.match(cleaned):
        raise ValidationError("Member ID must match format MEM-XXXX (e.g. MEM-1001).")
    return cleaned


def validate_date(
    value: str,
    field_name: str = "Date",
    min_year: int = 2015,
    max_year: int = 2035,
) -> str:
    cleaned = sanitize_text(value)
    if not cleaned:
        raise ValidationError(f"{field_name} cannot be blank (expected YYYY-MM-DD).")
    try:
        parsed = datetime.strptime(cleaned, "%Y-%m-%d").date()
    except ValueError as exc:
        raise ValidationError(f"{field_name} '{cleaned}' is invalid; use YYYY-MM-DD.") from exc
    if parsed.year < min_year or parsed.year > max_year:
        raise ValidationError(f"{field_name} year must be between {min_year} and {max_year}.")
    return parsed.isoformat()


def validate_date_order(start_iso: str, end_iso: str, start_label: str = "Start date", end_label: str = "End date") -> None:
    d1 = date.fromisoformat(start_iso)
    d2 = date.fromisoformat(end_iso)
    if d2 < d1:
        raise ValidationError(f"{end_label} ({end_iso}) cannot be earlier than {start_label} ({start_iso}).")


def validate_choice(value: str, allowed: Iterable[str], field_name: str = "Selection") -> str:
    cleaned = sanitize_text(value)
    if not cleaned:
        raise ValidationError(f"{field_name} cannot be blank.")
    lookup = {opt.lower(): opt for opt in allowed}
    key = cleaned.lower()
    if key not in lookup:
        raise ValidationError(f"Invalid {field_name}: '{cleaned}'. Allowed: {', '.join(allowed)}.")
    return lookup[key]


def validate_int(value: str, field_name: str, min_val: int = 0, max_val: int = 100000) -> int:
    cleaned = sanitize_text(value)
    if not cleaned:
        raise ValidationError(f"{field_name} cannot be blank.")
    try:
        num = int(cleaned)
    except ValueError as exc:
        raise ValidationError(f"{field_name} must be a whole number (received '{cleaned}').") from exc
    if num < min_val or num > max_val:
        raise ValidationError(f"{field_name} must be between {min_val} and {max_val}.")
    return num


def validate_float(value: str, field_name: str, min_val: float = 0.0, max_val: float = 10000.0) -> float:
    cleaned = sanitize_text(value)
    if not cleaned:
        raise ValidationError(f"{field_name} cannot be blank.")
    try:
        num = float(cleaned)
    except ValueError as exc:
        raise ValidationError(f"{field_name} must be a valid number (received '{cleaned}').") from exc
    if num < min_val or num > max_val:
        raise ValidationError(f"{field_name} must be between {min_val:.2f} and {max_val:.2f}.")
    return round(num, 2)


def validate_bool(value: str, field_name: str = "Value") -> bool:
    cleaned = sanitize_text(value).lower()
    if cleaned in ("y", "yes", "true", "1", "paid"):
        return True
    if cleaned in ("n", "no", "false", "0", "unpaid"):
        return False
    raise ValidationError(f"{field_name} must be yes/no (or true/false).")


def validate_member_row(row: dict[str, str], require_member_id: bool = False) -> tuple[dict[str, object], list[str]]:
    """Validate a raw dictionary (e.g. from CSV import) against Member schema."""
    errors: list[str] = []
    cleaned: dict[str, object] = {}

    raw_id = sanitize_text(row.get("member_id", ""))
    if raw_id:
        try:
            cleaned["member_id"] = validate_member_id(raw_id)
        except ValidationError as err:
            errors.append(str(err))
    elif require_member_id:
        errors.append("Missing member_id.")
    else:
        cleaned["member_id"] = ""

    for key, fn in (
        ("full_name", validate_full_name),
        ("email", validate_email),
        ("student_id", validate_student_id),
    ):
        try:
            cleaned[key] = fn(row.get(key, ""))
        except ValidationError as err:
            errors.append(str(err))

    try:
        cleaned["role"] = validate_choice(row.get("role", "Member") or "Member", VALID_ROLES, "Role")
    except ValidationError as err:
        errors.append(str(err))

    try:
        cleaned["membership_tier"] = validate_choice(
            row.get("membership_tier", "Standard") or "Standard", VALID_TIERS, "Membership tier"
        )
    except ValidationError as err:
        errors.append(str(err))

    try:
        cleaned["status"] = validate_choice(row.get("status", "Active") or "Active", VALID_MEMBER_STATUSES, "Status")
    except ValidationError as err:
        errors.append(str(err))

    try:
        cleaned["dues_paid"] = validate_bool(row.get("dues_paid", "false") or "false", "Dues paid")
    except ValidationError as err:
        errors.append(str(err))

    try:
        cleaned["dues_amount"] = validate_float(row.get("dues_amount", "25.0") or "25.0", "Dues amount", 0.0, 2000.0)
    except ValidationError as err:
        errors.append(str(err))

    join_val: Optional[str] = None
    renewal_val: Optional[str] = None
    try:
        join_val = validate_date(row.get("join_date", ""), "Join date")
        cleaned["join_date"] = join_val
    except ValidationError as err:
        errors.append(str(err))

    try:
        renewal_val = validate_date(row.get("renewal_due_date", ""), "Renewal due date")
        cleaned["renewal_due_date"] = renewal_val
    except ValidationError as err:
        errors.append(str(err))

    if join_val and renewal_val:
        try:
            validate_date_order(join_val, renewal_val, "Join date", "Renewal due date")
        except ValidationError as err:
            errors.append(str(err))

    try:
        cleaned["events_attended"] = validate_int(
            row.get("events_attended", "0") or "0", "Events attended", 0, 500
        )
    except ValidationError as err:
        errors.append(str(err))

    cleaned["notes"] = sanitize_text(row.get("notes", ""))[:200]
    return cleaned, errors


# ---------------------------------------------------------------------------
# Centralized Safe Console Input Wrappers
# ---------------------------------------------------------------------------

def safe_read_line(prompt: str) -> str:
    """Read a line from stdin without crashing on EOF or KeyboardInterrupt."""
    sys.stdout.write(prompt)
    sys.stdout.flush()
    line = sys.stdin.readline()
    if line == "":
        raise EOFError("End of input stream reached.")
    return line.rstrip("\r\n")


def prompt_validated(
    prompt: str,
    validator: Callable[[str], object],
    default: Optional[str] = None,
    allow_cancel: bool = True,
    error_printer: Optional[Callable[[str], None]] = None,
) -> Optional[object]:
    """Repeatedly prompt user until validator succeeds or user enters 'cancel'."""
    printer = error_printer or (lambda msg: print(f"  [ERROR] {msg}"))
    while True:
        suffix = f" [{default}]" if default is not None else ""
        cancel_hint = " (or 'cancel')" if allow_cancel else ""
        raw = safe_read_line(f"{prompt}{suffix}{cancel_hint}: ")
        cleaned = sanitize_text(raw)
        if allow_cancel and cleaned.lower() in ("cancel", "back", ":q"):
            return None
        if not cleaned and default is not None:
            cleaned = default
        try:
            return validator(cleaned)
        except ValidationError as err:
            printer(str(err))


def prompt_choice(
    prompt: str,
    options: Iterable[str],
    default: Optional[str] = None,
    allow_cancel: bool = True,
    error_printer: Optional[Callable[[str], None]] = None,
) -> Optional[str]:
    """Prompt user to pick an option by number or exact name."""
    option_list = list(options)
    print(f"  Available options: " + ", ".join(f"{idx}) {opt}" for idx, opt in enumerate(option_list, 1)))

    def _validate(raw: str) -> str:
        if raw.isdigit():
            idx = int(raw)
            if 1 <= idx <= len(option_list):
                return option_list[idx - 1]
            raise ValidationError(f"Choice number must be between 1 and {len(option_list)}.")
        return validate_choice(raw, option_list, "Option")

    result = prompt_validated(
        prompt,
        _validate,
        default=default,
        allow_cancel=allow_cancel,
        error_printer=error_printer,
    )
    return str(result) if result is not None else None


def prompt_confirm(prompt: str, default: bool = False) -> bool:
    default_str = "y" if default else "n"
    res = prompt_validated(
        f"{prompt} (y/n)",
        lambda raw: validate_bool(raw, "Confirmation"),
        default=default_str,
        allow_cancel=False,
    )
    return bool(res)


__all__ = [
    "ValidationError",
    "sanitize_text",
    "validate_non_empty",
    "validate_full_name",
    "validate_email",
    "validate_student_id",
    "validate_member_id",
    "validate_date",
    "validate_date_order",
    "validate_choice",
    "validate_int",
    "validate_float",
    "validate_bool",
    "validate_member_row",
    "safe_read_line",
    "prompt_validated",
    "prompt_choice",
    "prompt_confirm",
    "VALID_EVENT_CATEGORIES",
    "VALID_EVENT_STATUSES",
    "VALID_CHECKIN_STATUSES",
]
