"""Deterministic 40-record seed dataset demonstrating normal, boundary, and edge cases."""

from __future__ import annotations

from club_manager.models import (
    AttendanceRecord,
    AuditEntry,
    ClubEvent,
    ClubState,
    Member,
    MembershipList,
)


def build_sample_state() -> ClubState:
    """Create a realistic 40-member campus club dataset with events, attendance, and lists."""
    members_raw = [
        ("MEM-1001", "Aarav Mehta", "aarav.mehta@campus.edu", "STU-202401", "President", "Gold", "Active", True, 75.0, "2024-09-01", "2027-09-01", 14, "Leads executive board and hackathon outreach."),
        ("MEM-1002", "Maya Lin", "maya.lin@campus.edu", "STU-202402", "Vice President", "Gold", "Active", True, 75.0, "2024-09-03", "2027-09-03", 12, "Coordinates technical workshop series."),
        ("MEM-1003", "Liam O'Connor", "liam.oconnor@campus.edu", "STU-202403", "Treasurer", "Silver", "Active", True, 45.0, "2024-09-05", "2027-09-05", 10, "Manages club budget and sponsor invoices."),
        ("MEM-1004", "Sofia Rodriguez", "sofia.rodriguez@campus.edu", "STU-202404", "Secretary", "Silver", "Active", True, 45.0, "2024-09-08", "2027-09-08", 11, "Maintains meeting minutes and room bookings."),
        ("MEM-1005", "Dr. Evelyn Harper", "evelyn.harper@campus.edu", "FAC-1001", "Advisor", "Honorary", "Active", True, 0.0, "2023-08-20", "2028-08-20", 6, "Faculty advisor from Computer Science Dept."),
        ("MEM-1006", "Noah Kim", "noah.kim@campus.edu", "STU-202406", "Officer", "Gold", "Active", True, 75.0, "2025-01-14", "2027-01-14", 9, "Robotics lab equipment coordinator."),
        ("MEM-1007", "Priya Nair", "priya.nair@campus.edu", "STU-202407", "Officer", "Silver", "Active", True, 45.0, "2025-01-20", "2027-01-20", 8, "Designs promotional posters and social media."),
        ("MEM-1008", "Ethan Brooks", "ethan.brooks@campus.edu", "STU-202408", "Member", "Standard", "Active", True, 25.0, "2025-02-02", "2027-02-02", 5, "Interested in Python automation and CLI tools."),
        ("MEM-1009", "Chloe Dubois", "chloe.dubois@campus.edu", "STU-202409", "Member", "Silver", "Active", False, 45.0, "2025-02-10", "2026-10-15", 4, "EDGE: Overdue renewal and unpaid active dues."),
        ("MEM-1010", "Lucas Fernandez", "lucas.fernandez@campus.edu", "STU-202410", "Member", "Standard", "Active", True, 25.0, "2025-03-01", "2027-03-01", 6, "Attends weekly coding jams."),
        ("MEM-1011", "Zara Al-Mansoor", "zara.mansoor@campus.edu", "STU-202411", "Member", "Gold", "Active", True, 75.0, "2025-03-12", "2027-03-12", 7, "Mentors freshman Python study group."),
        ("MEM-1012", "Oliver Grant", "oliver.grant@campus.edu", "STU-202412", "Member", "Standard", "Pending", False, 25.0, "2026-11-05", "2027-11-05", 0, "BOUNDARY: New applicant awaiting dues confirmation."),
        ("MEM-1013", "Hannah Patel", "hannah.patel@campus.edu", "STU-202413", "Member", "Standard", "Active", True, 25.0, "2025-04-04", "2027-04-04", 0, "EDGE: Active >60 days with 0 events attended."),
        ("MEM-1014", "Daniel Cho", "daniel.cho@campus.edu", "STU-202414", "Member", "Silver", "Active", True, 45.0, "2025-04-18", "2027-04-18", 5, "Volunteer photographer for campus events."),
        ("MEM-1015", "Amara Okafor", "amara.okafor@campus.edu", "STU-202415", "Officer", "Gold", "Active", True, 75.0, "2025-05-01", "2027-05-01", 9, "Leads community outreach & STEM tutoring."),
        ("MEM-1016", "Benjamin Ross", "benjamin.ross@campus.edu", "STU-202416", "Member", "Standard", "Alumni", True, 25.0, "2022-09-01", "2026-06-01", 15, "Graduated Class of 2026; guest speaker."),
        ("MEM-1017", "Isabella Rossi", "isabella.rossi@campus.edu", "STU-202417", "Member", "Standard", "Active", False, 25.0, "2025-08-25", "2026-09-10", 2, "EDGE: Overdue by >30 days (CRITICAL flag)."),
        ("MEM-1018", "Gabriel Santos", "gabriel.santos@campus.edu", "STU-202418", "Member", "Silver", "Active", True, 45.0, "2025-09-02", "2027-09-02", 4, "Hardware prototyping team."),
        ("MEM-1019", "Nadia Kowalski", "nadia.kowalski@campus.edu", "STU-202419", "Member", "Standard", "Inactive", False, 25.0, "2025-09-10", "2026-09-10", 1, "Studying abroad this semester."),
        ("MEM-1020", "Caleb Wright", "caleb.wright@campus.edu", "STU-202420", "Member", "Standard", "Active", True, 25.0, "2025-09-15", "2027-09-15", 3, "Participates in competitive programming."),
        ("MEM-1021", "Sienna Takahashi", "sienna.takahashi@campus.edu", "STU-202421", "Member", "Gold", "Active", True, 75.0, "2025-10-01", "2027-10-01", 6, "UI/UX design lead for club showcase."),
        ("MEM-1022", "Marcus Vance", "marcus.vance@campus.edu", "STU-202422", "Member", "Standard", "Suspended", False, 25.0, "2025-10-08", "2026-10-08", 1, "EDGE: Suspended due to equipment policy breach."),
        ("MEM-1023", "Elena Petrova", "elena.petrova@campus.edu", "STU-202423", "Member", "Silver", "Active", True, 45.0, "2026-01-12", "2027-01-12", 5, "Data science study circle coordinator."),
        ("MEM-1024", "Ryan Gallagher", "ryan.gallagher@campus.edu", "STU-202424", "Member", "Standard", "Active", True, 25.0, "2026-01-22", "2027-01-22", 3, "Focuses on Linux & open-source tooling."),
        ("MEM-1025", "Fatima Zahra", "fatima.zahra@campus.edu", "STU-202425", "Member", "Silver", "Active", True, 45.0, "2026-02-05", "2027-02-05", 4, "Coordinates inter-club lightning talks."),
        ("MEM-1026", "Owen Mercer", "owen.mercer@campus.edu", "STU-202426", "Member", "Standard", "Active", False, 25.0, "2026-02-14", "2027-02-14", 2, "EDGE: Active member with pending dues payment."),
        ("MEM-1027", "Grace Osei", "grace.osei@campus.edu", "STU-202427", "Member", "Gold", "Active", True, 75.0, "2026-03-03", "2027-03-03", 5, "Sponsors & alumni liaison assistant."),
        ("MEM-1028", "Julian Alvarez", "julian.alvarez@campus.edu", "STU-202428", "Member", "Standard", "Active", True, 25.0, "2026-03-19", "2027-03-19", 2, "Cybersecurity CTF squad member."),
        ("MEM-1029", "Aria Montgomery", "aria.montgomery@campus.edu", "STU-202429", "Member", "Standard", "Alumni", True, 25.0, "2023-09-01", "2026-05-15", 11, "Former club secretary, now industry mentor."),
        ("MEM-1030", "Devansh Kulkarni", "devansh.kulkarni@campus.edu", "STU-202430", "Member", "Silver", "Active", True, 45.0, "2026-06-10", "2027-06-10", 3, "Embedded systems & IoT projects."),
        ("MEM-1031", "Tessa Lindqvist", "tessa.lindqvist@campus.edu", "STU-202431", "Member", "Standard", "Active", True, 25.0, "2026-07-04", "2027-07-04", 2, "Joined during summer orientation."),
        ("MEM-1032", "Kieran Murphy", "kieran.murphy@campus.edu", "STU-202432", "Member", "Standard", "Pending", False, 25.0, "2026-11-12", "2027-11-12", 0, "Pending orientation sign-off."),
        ("MEM-1033", "Meera Subramanian", "meera.subramanian@campus.edu", "STU-202433", "Member", "Gold", "Active", True, 75.0, "2026-08-18", "2027-08-18", 4, "Cloud engineering & DevOps workshop lead."),
        ("MEM-1034", "Victor Hugo", "victor.hugo@campus.edu", "STU-202434", "Member", "Standard", "Active", True, 25.0, "2026-08-29", "2027-08-29", 3, "Game dev track participant."),
        ("MEM-1035", "Claire Bennett", "claire.bennett@campus.edu", "STU-202435", "Member", "Silver", "Active", True, 45.0, "2026-09-04", "2027-09-04", 3, "Accessibility & documentation champion."),
        ("MEM-1036", "Tariq Hassan", "tariq.hassan@campus.edu", "STU-202436", "Member", "Standard", "Active", True, 25.0, "2026-09-12", "2027-09-12", 2, "Freshman hackathon track finalist."),
        ("MEM-1037", "Natalie Wong", "natalie.wong@campus.edu", "STU-202437", "Member", "Honorary", "Active", True, 0.0, "2026-09-20", "2027-09-20", 1, "BOUNDARY: Honorary guest scholar ($0 dues)."),
        ("MEM-1038", "Samir Malhotra", "samir.malhotra@campus.edu", "STU-202438", "Member", "Standard", "Active", True, 25.0, "2026-10-02", "2027-10-02", 2, "Algorithms & interview prep lead."),
        ("MEM-1039", "Eva Novak", "eva.novak@campus.edu", "STU-202439", "Member", "Silver", "Active", True, 45.0, "2026-10-15", "2027-10-15", 1, "Open-source documentation contributor."),
        ("MEM-1040", "Jordan Blake", "jordan.blake@campus.edu", "STU-202440", "Member", "Standard", "Active", True, 25.0, "2026-11-01", "2027-11-01", 1, "Newest active standard member."),
    ]

    members = [
        Member(
            member_id=row[0],
            full_name=row[1],
            email=row[2],
            student_id=row[3],
            role=row[4],
            membership_tier=row[5],
            status=row[6],
            dues_paid=row[7],
            dues_amount=row[8],
            join_date=row[9],
            renewal_due_date=row[10],
            events_attended=row[11],
            notes=row[12],
        )
        for row in members_raw
    ]

    events = [
        ClubEvent("EVT-201", "Fall General Assembly", "General Meeting", "2026-09-10", "Engineering Hall 101", 60, "Completed", "Semester kickoff & committee signups."),
        ClubEvent("EVT-202", "Python CLI Architecture Workshop", "Workshop", "2026-09-24", "Innovation Lab B", 30, "Completed", "Building modular zero-dependency terminal apps."),
        ClubEvent("EVT-203", "FutureReady Campus Hackathon", "Hackathon", "2026-10-18", "Student Union Ballroom", 50, "Completed", "24-hour student build sprint."),
        ClubEvent("EVT-204", "STEM Community Tutoring Day", "Community Service", "2026-11-02", "Civic Youth Center", 20, "Completed", "Mentoring local high-school coders."),
        ClubEvent("EVT-205", "Algorithmic Problem Solving Jam", "Competition", "2026-11-14", "CS Building 304", 25, "Completed", "Timed team coding challenge."),
        ClubEvent("EVT-206", "Winter Project Showcase Prep", "Workshop", "2026-11-28", "Maker Space 202", 10, "Upcoming", "Demo polish clinic (near capacity)."),
        ClubEvent("EVT-207", "End-of-Term Mixer & Awards", "Social", "2026-12-10", "Campus Commons", 80, "Upcoming", "Celebration & officer elections."),
        ClubEvent("EVT-208", "Spring Robotics Orientation", "Workshop", "2027-01-18", "Robotics Bay 12", 24, "Upcoming", "Safety briefing and kit distribution."),
    ]

    attendance_pairs = [
        ("ATT-5001", "EVT-201", "MEM-1001", "Attended", 2.0, "2026-09-10 18:00:00", 5),
        ("ATT-5002", "EVT-201", "MEM-1002", "Attended", 2.0, "2026-09-10 18:02:00", 5),
        ("ATT-5003", "EVT-201", "MEM-1003", "Attended", 2.0, "2026-09-10 18:04:00", 4),
        ("ATT-5004", "EVT-201", "MEM-1004", "Attended", 2.0, "2026-09-10 18:05:00", 5),
        ("ATT-5005", "EVT-201", "MEM-1005", "Attended", 1.5, "2026-09-10 18:10:00", 5),
        ("ATT-5006", "EVT-201", "MEM-1008", "Attended", 2.0, "2026-09-10 18:12:00", 4),
        ("ATT-5007", "EVT-201", "MEM-1010", "Attended", 2.0, "2026-09-10 18:15:00", 5),
        ("ATT-5008", "EVT-201", "MEM-1040", "RSVP", 0.0, "2026-09-09 14:00:00", 4),
        ("ATT-5009", "EVT-202", "MEM-1001", "Attended", 2.5, "2026-09-24 17:30:00", 5),
        ("ATT-5010", "EVT-202", "MEM-1002", "Attended", 2.5, "2026-09-24 17:31:00", 5),
        ("ATT-5011", "EVT-202", "MEM-1006", "Attended", 2.5, "2026-09-24 17:35:00", 4),
        ("ATT-5012", "EVT-202", "MEM-1011", "Attended", 2.5, "2026-09-24 17:36:00", 5),
        ("ATT-5013", "EVT-202", "MEM-1023", "Attended", 2.5, "2026-09-24 17:40:00", 5),
        ("ATT-5014", "EVT-202", "MEM-1033", "Attended", 2.5, "2026-09-24 17:41:00", 4),
        ("ATT-5015", "EVT-202", "MEM-1035", "Attended", 2.5, "2026-09-24 17:42:00", 5),
        ("ATT-5016", "EVT-203", "MEM-1001", "Attended", 8.0, "2026-10-18 09:00:00", 5),
        ("ATT-5017", "EVT-203", "MEM-1002", "Attended", 8.0, "2026-10-18 09:00:00", 5),
        ("ATT-5018", "EVT-203", "MEM-1004", "Attended", 8.0, "2026-10-18 09:05:00", 5),
        ("ATT-5019", "EVT-203", "MEM-1007", "Attended", 8.0, "2026-10-18 09:10:00", 4),
        ("ATT-5020", "EVT-203", "MEM-1015", "Attended", 8.0, "2026-10-18 09:12:00", 5),
        ("ATT-5021", "EVT-203", "MEM-1021", "Attended", 8.0, "2026-10-18 09:15:00", 5),
        ("ATT-5022", "EVT-203", "MEM-1036", "Attended", 8.0, "2026-10-18 09:20:00", 5),
        ("ATT-5023", "EVT-203", "MEM-1038", "Attended", 8.0, "2026-10-18 09:25:00", 4),
        ("ATT-5024", "EVT-204", "MEM-1015", "Attended", 4.0, "2026-11-02 10:00:00", 5),
        ("ATT-5025", "EVT-204", "MEM-1011", "Attended", 4.0, "2026-11-02 10:02:00", 5),
        ("ATT-5026", "EVT-204", "MEM-1025", "Attended", 4.0, "2026-11-02 10:05:00", 4),
        ("ATT-5027", "EVT-204", "MEM-1035", "Attended", 4.0, "2026-11-02 10:08:00", 5),
        ("ATT-5028", "EVT-205", "MEM-1020", "Attended", 3.0, "2026-11-14 14:00:00", 4),
        ("ATT-5029", "EVT-205", "MEM-1028", "Attended", 3.0, "2026-11-14 14:02:00", 4),
        ("ATT-5030", "EVT-205", "MEM-1038", "Attended", 3.0, "2026-11-14 14:05:00", 5),
        ("ATT-5031", "EVT-205", "MEM-1010", "Attended", 3.0, "2026-11-14 14:08:00", 4),
        # EVT-206 has capacity 10 and 9 RSVPs -> triggers EVENT_NEAR_CAPACITY (90%) warning
        ("ATT-5032", "EVT-206", "MEM-1001", "RSVP", 0.0, "2026-11-15 11:00:00", 5),
        ("ATT-5033", "EVT-206", "MEM-1002", "RSVP", 0.0, "2026-11-15 11:05:00", 5),
        ("ATT-5034", "EVT-206", "MEM-1006", "RSVP", 0.0, "2026-11-15 11:10:00", 5),
        ("ATT-5035", "EVT-206", "MEM-1014", "RSVP", 0.0, "2026-11-15 11:15:00", 5),
        ("ATT-5036", "EVT-206", "MEM-1018", "RSVP", 0.0, "2026-11-15 11:20:00", 5),
        ("ATT-5037", "EVT-206", "MEM-1021", "RSVP", 0.0, "2026-11-15 11:25:00", 5),
        ("ATT-5038", "EVT-206", "MEM-1024", "RSVP", 0.0, "2026-11-15 11:30:00", 5),
        ("ATT-5039", "EVT-206", "MEM-1030", "RSVP", 0.0, "2026-11-15 11:35:00", 5),
        ("ATT-5040", "EVT-206", "MEM-1039", "RSVP", 0.0, "2026-11-15 11:40:00", 5),
    ]

    attendance = [
        AttendanceRecord(
            record_id=rec[0],
            event_id=rec[1],
            member_id=rec[2],
            check_in_status=rec[3],
            hours_credited=rec[4],
            recorded_at=rec[5],
            feedback_score=rec[6],
        )
        for rec in attendance_pairs
    ]

    membership_lists = [
        MembershipList(
            list_id="LST-301",
            name="Executive Board",
            category="Governance",
            description="Elected officers and faculty advisor.",
            member_ids=["MEM-1001", "MEM-1002", "MEM-1003", "MEM-1004", "MEM-1005", "MEM-1006", "MEM-1007", "MEM-1015"],
            created_at="2024-09-01",
        ),
        MembershipList(
            list_id="LST-302",
            name="Hackathon Logistics Crew",
            category="Event Committee",
            description="Volunteers organizing FutureReady Hack.",
            member_ids=["MEM-1001", "MEM-1004", "MEM-1007", "MEM-1015", "MEM-1021", "MEM-1035", "MEM-1036"],
            created_at="2026-09-15",
        ),
        MembershipList(
            list_id="LST-303",
            name="Workshop Mentors",
            category="Education",
            description="Peer mentors leading Python and Cloud labs.",
            member_ids=["MEM-1002", "MEM-1011", "MEM-1023", "MEM-1033", "MEM-1038"],
            created_at="2026-09-20",
        ),
        MembershipList(
            list_id="LST-304",
            name="Dues & Renewal Follow-Up",
            category="Administration",
            description="Members requiring treasurer outreach for dues/renewals.",
            member_ids=["MEM-1009", "MEM-1012", "MEM-1017", "MEM-1026", "MEM-1032"],
            created_at="2026-11-01",
        ),
        MembershipList(
            list_id="LST-305",
            name="Alumni Advisory Network",
            category="Alumni",
            description="Graduated members supporting mock interviews & panels.",
            member_ids=["MEM-1016", "MEM-1029"],
            created_at="2026-06-15",
        ),
    ]

    audit_log = [
        AuditEntry("2026-09-01 09:00:00", "INIT_SEED", "SYSTEM", "Initialized 40 sample club members across CSV and JSON storage."),
        AuditEntry("2026-10-18 21:00:00", "EVENT_CLOSED", "EVT-203", "FutureReady Campus Hackathon completed with 8 logged participants."),
        AuditEntry("2026-11-15 11:45:00", "LIST_SYNC", "LST-304", "Updated Dues & Renewal Follow-Up list."),
    ]

    return ClubState(
        club_name="Campus Innovators & Builders Club",
        members=members,
        events=events,
        attendance=attendance,
        membership_lists=membership_lists,
        audit_log=audit_log,
    )
