"""Local CSV and JSON persistence layer with corruption recovery."""

from __future__ import annotations

import csv
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any

from club_manager.models import (
    AttendanceRecord,
    AuditEntry,
    ClubEvent,
    ClubState,
    Member,
    MembershipList,
)
from club_manager.seed_data import build_sample_state
from club_manager.validators import validate_member_row

MEMBER_CSV_FIELDS = [
    "member_id",
    "full_name",
    "email",
    "student_id",
    "role",
    "membership_tier",
    "status",
    "dues_paid",
    "dues_amount",
    "join_date",
    "renewal_due_date",
    "events_attended",
    "notes",
]


class StorageError(RuntimeError):
    """Raised when reading an external import file fails."""


def _backup_corrupt_file(path: Path) -> str:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = path.with_name(f"{path.name}.corrupt.{timestamp}.bak")
    try:
        shutil.copy2(path, backup_path)
        return str(backup_path)
    except OSError:
        return ""


def _read_members_csv(csv_path: Path) -> tuple[list[Member], list[str]]:
    notices: list[str] = []
    members: list[Member] = []
    with csv_path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        if not reader.fieldnames:
            raise ValueError("members.csv is empty or missing header row.")
        missing_cols = [c for c in ("member_id", "full_name", "email", "student_id") if c not in reader.fieldnames]
        if missing_cols:
            raise ValueError(f"members.csv missing required columns: {', '.join(missing_cols)}")
        for line_num, raw_row in enumerate(reader, start=2):
            cleaned, errs = validate_member_row(raw_row, require_member_id=True)
            if errs:
                notices.append(f"Skipped malformed CSV row {line_num}: {'; '.join(errs)}")
                continue
            members.append(
                Member(
                    member_id=str(cleaned["member_id"]),
                    full_name=str(cleaned["full_name"]),
                    email=str(cleaned["email"]),
                    student_id=str(cleaned["student_id"]),
                    role=str(cleaned["role"]),
                    membership_tier=str(cleaned["membership_tier"]),
                    status=str(cleaned["status"]),
                    dues_paid=bool(cleaned["dues_paid"]),
                    dues_amount=float(cleaned["dues_amount"]),
                    join_date=str(cleaned["join_date"]),
                    renewal_due_date=str(cleaned["renewal_due_date"]),
                    events_attended=int(cleaned["events_attended"]),
                    notes=str(cleaned["notes"]),
                )
            )
    return members, notices


def _read_club_json(json_path: Path) -> dict[str, Any]:
    with json_path.open("r", encoding="utf-8") as fh:
        payload = json.load(fh)
    if not isinstance(payload, dict):
        raise ValueError("club_data.json root must be a JSON object.")
    return payload


def load_state(data_dir: str | Path = "data") -> ClubState:
    """Load application state from CSV and JSON files, recovering gracefully if missing or corrupted."""
    base_dir = Path(data_dir)
    base_dir.mkdir(parents=True, exist_ok=True)
    csv_path = base_dir / "members.csv"
    json_path = base_dir / "club_data.json"

    notices: list[str] = []
    json_payload: dict[str, Any] | None = None
    csv_members: list[Member] | None = None

    if json_path.exists():
        try:
            json_payload = _read_club_json(json_path)
        except (json.JSONDecodeError, ValueError, OSError) as exc:
            bak = _backup_corrupt_file(json_path)
            notices.append(
                f"Detected corrupted JSON file '{json_path.name}' ({exc}). "
                + (f"Backed up to {Path(bak).name}. " if bak else "")
                + "Recovering state."
            )
            json_payload = None
    else:
        notices.append(f"'{json_path.name}' not found; will initialize clean JSON storage.")

    if csv_path.exists():
        try:
            csv_members, row_notices = _read_members_csv(csv_path)
            notices.extend(row_notices)
        except (csv.Error, ValueError, OSError) as exc:
            bak = _backup_corrupt_file(csv_path)
            notices.append(
                f"Detected corrupted CSV file '{csv_path.name}' ({exc}). "
                + (f"Backed up to {Path(bak).name}. " if bak else "")
                + "Recovering member records."
            )
            csv_members = None
    else:
        notices.append(f"'{csv_path.name}' not found; will initialize clean CSV storage.")

    if csv_members is None and json_payload is None:
        state = build_sample_state()
        if notices:
            state.startup_notices = ["Initialized sample 40-member dataset (CSV + JSON)."]
        save_state(state, base_dir)
        return state

    # Build state from available files, using CSV as primary member list if present, else JSON mirror
    seed_fallback = build_sample_state()

    if csv_members is not None:
        members = csv_members
    elif json_payload and isinstance(json_payload.get("members"), list):
        members = []
        for item in json_payload["members"]:
            if isinstance(item, dict):
                try:
                    members.append(Member.from_dict(item))
                except (ValueError, TypeError):
                    continue
        notices.append("Restored member directory from club_data.json mirror.")
    else:
        members = seed_fallback.members
        notices.append("Restored member directory from default seed dataset.")

    if json_payload is not None:
        club_name = str(json_payload.get("club_name") or seed_fallback.club_name)
        events = _safe_parse_list(json_payload.get("events"), ClubEvent.from_dict, notices, "events")
        attendance = _safe_parse_list(json_payload.get("attendance"), AttendanceRecord.from_dict, notices, "attendance")
        membership_lists = _safe_parse_list(
            json_payload.get("membership_lists"), MembershipList.from_dict, notices, "membership_lists"
        )
        audit_log = _safe_parse_list(json_payload.get("audit_log"), AuditEntry.from_dict, notices, "audit_log")
    else:
        club_name = seed_fallback.club_name
        events = seed_fallback.events
        attendance = seed_fallback.attendance
        membership_lists = seed_fallback.membership_lists
        audit_log = seed_fallback.audit_log
        notices.append("Restored events, attendance, and membership lists cleanly.")

    state = ClubState(
        club_name=club_name,
        members=members,
        events=events,
        attendance=attendance,
        membership_lists=membership_lists,
        audit_log=audit_log,
        startup_notices=notices,
    )
    # Ensure both CSV and JSON are synchronized after recovery
    if notices:
        save_state(state, base_dir)
    return state


def _safe_parse_list(raw_items: Any, factory: Any, notices: list[str], label: str) -> list[Any]:
    if not isinstance(raw_items, list):
        notices.append(f"Missing or malformed '{label}' section in JSON; initialized empty list.")
        return []
    parsed: list[Any] = []
    for idx, item in enumerate(raw_items):
        if not isinstance(item, dict):
            notices.append(f"Skipped invalid entry #{idx + 1} in '{label}'.")
            continue
        try:
            parsed.append(factory(item))
        except (ValueError, TypeError) as exc:
            notices.append(f"Skipped malformed entry #{idx + 1} in '{label}': {exc}")
    return parsed


def save_state(state: ClubState, data_dir: str | Path = "data") -> tuple[Path, Path]:
    """Persist application state atomically to both CSV and JSON local files."""
    base_dir = Path(data_dir)
    base_dir.mkdir(parents=True, exist_ok=True)
    csv_path = base_dir / "members.csv"
    json_path = base_dir / "club_data.json"

    tmp_csv = base_dir / "members.csv.tmp"
    with tmp_csv.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=MEMBER_CSV_FIELDS)
        writer.writeheader()
        for member in state.members:
            row = member.to_dict()
            row["dues_paid"] = "true" if member.dues_paid else "false"
            row["dues_amount"] = f"{member.dues_amount:.2f}"
            writer.writerow({k: row[k] for k in MEMBER_CSV_FIELDS})
    tmp_csv.replace(csv_path)

    tmp_json = base_dir / "club_data.json.tmp"
    payload = {
        "schema_version": "1.0",
        "club_name": state.club_name,
        "last_saved": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "record_counts": {
            "members": len(state.members),
            "events": len(state.events),
            "attendance": len(state.attendance),
            "membership_lists": len(state.membership_lists),
        },
        "members": [m.to_dict() for m in state.members],
        "events": [e.to_dict() for e in state.events],
        "attendance": [a.to_dict() for a in state.attendance],
        "membership_lists": [lst.to_dict() for lst in state.membership_lists],
        "audit_log": [entry.to_dict() for entry in state.audit_log[-250:]],
    }
    with tmp_json.open("w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)
    tmp_json.replace(json_path)

    return csv_path, json_path


def read_bulk_csv(file_path: str | Path) -> list[dict[str, str]]:
    """Read an external CSV dataset for bulk import validation."""
    target = Path(file_path)
    if not target.exists():
        raise StorageError(f"CSV file not found: '{target}'.")
    if not target.is_file():
        raise StorageError(f"Path is not a regular file: '{target}'.")

    try:
        with target.open("r", encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh)
            if not reader.fieldnames:
                raise StorageError("Import CSV is empty or missing a header row.")
            required = {"full_name", "email", "student_id"}
            missing = sorted(required - set(reader.fieldnames))
            if missing:
                raise StorageError(f"Import CSV is missing required column(s): {', '.join(missing)}.")
            return [dict(row) for row in reader]
    except UnicodeDecodeError as exc:
        raise StorageError(f"File '{target}' is not valid UTF-8 text.") from exc
    except csv.Error as exc:
        raise StorageError(f"CSV syntax error in '{target}': {exc}") from exc
    except OSError as exc:
        raise StorageError(f"Unable to read '{target}': {exc}") from exc
