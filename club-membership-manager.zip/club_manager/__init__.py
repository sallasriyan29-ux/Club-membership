"""Club Membership Manager package."""

__version__ = "1.0.0"
__app_name__ = "Club Membership Manager"
