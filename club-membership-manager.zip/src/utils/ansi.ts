export type AnsiTone = 'default' | 'cyan' | 'green' | 'yellow' | 'red' | 'dim' | 'bold';

export interface AnsiSegment {
  text: string;
  tone: AnsiTone;
  bold: boolean;
}

const ANSI_PATTERN = /\x1b\[([0-9;]*)m/g;

export function parseAnsiSegments(input: string): AnsiSegment[] {
  const segments: AnsiSegment[] = [];
  let lastIndex = 0;
  let currentTone: AnsiTone = 'default';
  let currentBold = false;

  for (const match of input.matchAll(ANSI_PATTERN)) {
    const matchIndex = match.index ?? 0;
    if (matchIndex > lastIndex) {
      segments.push({
        text: input.slice(lastIndex, matchIndex),
        tone: currentTone,
        bold: currentBold,
      });
    }
    const codes = (match[1] || '0').split(';').map((c) => Number.parseInt(c, 10));
    for (const code of codes) {
      if (code === 0 || Number.isNaN(code)) {
        currentTone = 'default';
        currentBold = false;
      } else if (code === 1) {
        currentBold = true;
      } else if (code === 2) {
        currentTone = 'dim';
      } else if (code === 31) {
        currentTone = 'red';
      } else if (code === 32) {
        currentTone = 'green';
      } else if (code === 33) {
        currentTone = 'yellow';
      } else if (code === 36) {
        currentTone = 'cyan';
      }
    }
    lastIndex = matchIndex + match[0].length;
  }

  if (lastIndex < input.length) {
    segments.push({
      text: input.slice(lastIndex),
      tone: currentTone,
      bold: currentBold,
    });
  }

  return segments;
}
