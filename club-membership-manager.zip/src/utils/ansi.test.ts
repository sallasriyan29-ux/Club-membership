import test from 'node:test';
import assert from 'node:assert/strict';
import { parseAnsiSegments } from './ansi';

test('parseAnsiSegments preserves plain text', () => {
  const segs = parseAnsiSegments('Hello Club');
  assert.deepEqual(segs, [{ text: 'Hello Club', tone: 'default', bold: false }]);
});

test('parseAnsiSegments parses color and bold reset sequences', () => {
  const segs = parseAnsiSegments('\x1b[32m[OK]\x1b[0m \x1b[1mSaved\x1b[0m');
  assert.deepEqual(segs, [
    { text: '[OK]', tone: 'green', bold: false },
    { text: ' ', tone: 'default', bold: false },
    { text: 'Saved', tone: 'default', bold: true },
  ]);
});
