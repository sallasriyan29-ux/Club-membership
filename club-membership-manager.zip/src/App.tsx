import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  FileCode2,
  FolderOpen,
  Play,
  RefreshCw,
  RotateCcw,
  Send,
  Square,
  Terminal as TerminalIcon,
} from 'lucide-react';
import { parseAnsiSegments, type AnsiTone } from './utils/ansi';

interface WorkspaceFile {
  path: string;
  category: string;
  size: number;
}

const TONE_CLASSES: Record<AnsiTone, string> = {
  default: 'text-slate-200',
  cyan: 'text-cyan-300',
  green: 'text-emerald-400',
  yellow: 'text-amber-300',
  red: 'text-rose-400',
  dim: 'text-slate-400',
  bold: 'text-white',
};

const QUICK_COMMANDS: Array<{ label: string; value: string; hint: string }> = [
  { label: '1 · Members', value: '1', hint: 'Open Member Directory' },
  { label: '2 · Search', value: '2', hint: 'Search & Filter Records' },
  { label: '3 · Events', value: '3', hint: 'Event Participation' },
  { label: '4 · Lists', value: '4', hint: 'Membership Lists' },
  { label: '5 · Summary', value: '5', hint: 'Executive Summary & Charts' },
  { label: '6 · Warnings', value: '6', hint: 'Threshold Warning Scan' },
  { label: '7 · Bulk CSV', value: '7', hint: 'Bulk CSV Dataset Import' },
  { label: '8 · Exports', value: '8', hint: 'Export MD / TXT / CSV' },
  { label: '0 · Save & Exit', value: '0', hint: 'Save and exit CLI' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'terminal' | 'files'>('terminal');
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [output, setOutput] = useState<string>('');
  const [exited, setExited] = useState<boolean>(false);
  const [exitCode, setExitCode] = useState<number | null>(null);
  const [inputValue, setInputValue] = useState<string>('');
  const [starting, setStarting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [files, setFiles] = useState<WorkspaceFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<string>('data/members.csv');
  const [fileContent, setFileContent] = useState<string>('');
  const [loadingFile, setLoadingFile] = useState<boolean>(false);

  const offsetRef = useRef<number>(0);
  const sessionRef = useRef<string | null>(null);
  const terminalEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const refreshFiles = useCallback(async () => {
    try {
      const res = await fetch('/api/files');
      if (!res.ok) return;
      const data = (await res.json()) as { files: WorkspaceFile[] };
      setFiles(data.files);
    } catch {
      // Ignore transient refresh errors
    }
  }, []);

  const loadFileContent = useCallback(async (relPath: string) => {
    setLoadingFile(true);
    setSelectedFile(relPath);
    try {
      const res = await fetch(`/api/file?path=${encodeURIComponent(relPath)}`);
      if (!res.ok) {
        setFileContent('Unable to read file.');
        return;
      }
      const data = (await res.json()) as { content: string };
      setFileContent(data.content);
    } catch {
      setFileContent('Failed to fetch file content.');
    } finally {
      setLoadingFile(false);
    }
  }, []);

  const startSession = useCallback(async () => {
    setStarting(true);
    setErrorMsg(null);
    if (sessionRef.current) {
      await fetch('/api/terminal/stop', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: sessionRef.current }),
      }).catch(() => {});
    }

    offsetRef.current = 0;
    setOutput('');
    setExited(false);
    setExitCode(null);

    try {
      const res = await fetch('/api/terminal/start', { method: 'POST' });
      if (!res.ok) {
        throw new Error('Failed to launch python3 main.py');
      }
      const data = (await res.json()) as { sessionId: string };
      sessionRef.current = data.sessionId;
      setSessionId(data.sessionId);
      setTimeout(() => inputRef.current?.focus(), 80);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to start Python session.');
    } finally {
      setStarting(false);
    }
  }, []);

  useEffect(() => {
    void startSession();
    void refreshFiles();
    return () => {
      if (sessionRef.current) {
        void fetch('/api/terminal/stop', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sessionId: sessionRef.current }),
        }).catch(() => {});
      }
    };
  }, [startSession, refreshFiles]);

  useEffect(() => {
    if (!sessionId) return;
    let cancelled = false;
    let inFlight = false;

    const poll = async () => {
      if (cancelled || inFlight) return;
      inFlight = true;
      try {
        const res = await fetch(
          `/api/terminal/output?sessionId=${encodeURIComponent(sessionId)}&offset=${offsetRef.current}`
        );
        if (!res.ok) return;
        const data = (await res.json()) as {
          chunk: string;
          nextOffset: number;
          exited: boolean;
          exitCode: number | null;
        };
        if (cancelled) return;
        if (data.chunk && data.nextOffset > offsetRef.current) {
          offsetRef.current = data.nextOffset;
          setOutput((prev) => prev + data.chunk);
        }
        if (data.exited) {
          setExited(true);
          setExitCode(data.exitCode);
          void refreshFiles();
        }
      } catch {
        // Ignore transient polling hiccups
      } finally {
        inFlight = false;
      }
    };

    const timer = setInterval(() => {
      void poll();
    }, 160);
    void poll();
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, [sessionId, refreshFiles]);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [output]);

  useEffect(() => {
    if (activeTab === 'files') {
      void refreshFiles();
      if (selectedFile) {
        void loadFileContent(selectedFile);
      }
    }
  }, [activeTab, refreshFiles, loadFileContent, selectedFile]);

  const sendLine = useCallback(
    async (text: string) => {
      if (!sessionId || exited) return;
      setErrorMsg(null);
      try {
        const res = await fetch('/api/terminal/input', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sessionId, input: text }),
        });
        if (!res.ok) {
          const payload = (await res.json().catch(() => ({}))) as { error?: string };
          setErrorMsg(payload.error || 'Failed to send input to Python CLI.');
        }
      } catch {
        setErrorMsg('Connection error while sending input.');
      }
    },
    [sessionId, exited]
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const toSend = inputValue;
    setInputValue('');
    void sendLine(toSend);
  };

  const stopSession = async () => {
    if (!sessionId) return;
    await fetch('/api/terminal/stop', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId }),
    }).catch(() => {});
    setExited(true);
    setExitCode(0);
  };

  const parsedSegments = useMemo(() => parseAnsiSegments(output), [output]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      <header className="border-b border-slate-800 bg-slate-900/90 px-4 py-3">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-300">
              <TerminalIcon className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base font-semibold tracking-tight text-white">
                Club Membership Manager
              </h1>
              <p className="text-xs text-slate-400">
                Python 3.11 Standard Library CLI · Local CSV &amp; JSON Persistence
              </p>
            </div>
          </div>

          <nav aria-label="Workspace Views" className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('terminal')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium border transition ${
                activeTab === 'terminal'
                  ? 'bg-cyan-500/20 border-cyan-400/50 text-cyan-200'
                  : 'bg-slate-800/70 border-slate-700 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <TerminalIcon className="w-3.5 h-3.5" />
              Interactive Python CLI
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('files')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium border transition ${
                activeTab === 'files'
                  ? 'bg-cyan-500/20 border-cyan-400/50 text-cyan-200'
                  : 'bg-slate-800/70 border-slate-700 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <FolderOpen className="w-3.5 h-3.5" />
              Data &amp; Exported Reports
            </button>
          </nav>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 flex flex-col gap-4">
        {activeTab === 'terminal' ? (
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-[1fr_290px] gap-4 min-h-0">
            <section
              aria-label="Python Terminal Output"
              className="flex flex-col rounded-xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl min-h-[540px] max-h-[calc(100vh-140px)]"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 bg-slate-900 border-b border-slate-800">
                <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
                  <span
                    className={`inline-block w-2 h-2 rounded-full ${
                      exited ? 'bg-amber-400' : 'bg-emerald-400'
                    }`}
                  />
                  <span>python3 -u main.py</span>
                  {exited && (
                    <span className="text-amber-300">
                      (Exited{exitCode !== null ? ` · code ${exitCode}` : ''})
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => void startSession()}
                    disabled={starting}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-200 transition disabled:opacity-50"
                  >
                    {exited ? <Play className="w-3.5 h-3.5 text-emerald-400" /> : <RotateCcw className="w-3.5 h-3.5 text-cyan-300" />}
                    {exited ? 'Relaunch CLI' : 'Restart Session'}
                  </button>
                  {!exited && (
                    <button
                      type="button"
                      onClick={() => void stopSession()}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-rose-950/60 border border-slate-700 hover:border-rose-700/60 text-xs text-slate-300 hover:text-rose-200 transition"
                    >
                      <Square className="w-3 h-3" />
                      Stop
                    </button>
                  )}
                </div>
              </div>

              <div
                data-testid="terminal-transcript"
                className="flex-1 overflow-y-auto p-4 font-mono text-xs sm:text-[13px] leading-relaxed bg-[#080d1a] whitespace-pre-wrap break-words"
                onClick={() => inputRef.current?.focus()}
              >
                {parsedSegments.map((seg, idx) => (
                  <span
                    key={idx}
                    className={`${TONE_CLASSES[seg.tone]} ${seg.bold ? 'font-bold' : ''}`}
                  >
                    {seg.text}
                  </span>
                ))}
                <div ref={terminalEndRef} />
              </div>

              {errorMsg && (
                <div role="alert" className="px-4 py-2 bg-rose-950/70 border-t border-rose-800/70 text-xs text-rose-200">
                  {errorMsg}
                </div>
              )}

              <form
                onSubmit={handleSubmit}
                className="flex items-center gap-2 px-3 py-2.5 bg-slate-900 border-t border-slate-800"
              >
                <label htmlFor="cli-input" className="font-mono text-sm text-cyan-400 select-none pl-1">
                  &gt;
                </label>
                <input
                  id="cli-input"
                  ref={inputRef}
                  type="text"
                  value={inputValue}
                  disabled={exited}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder={
                    exited
                      ? 'Process exited — click Relaunch CLI to test persistence across restarts'
                      : 'Type menu choice or input and press Enter (blank submits Enter)...'
                  }
                  className="flex-1 bg-slate-950 border border-slate-700 focus:border-cyan-400 focus:outline-none rounded-md px-3 py-1.5 font-mono text-xs sm:text-sm text-white placeholder:text-slate-500 disabled:opacity-50"
                />
                <button
                  type="submit"
                  disabled={exited}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-medium transition disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  Send
                </button>
              </form>
            </section>

            <aside className="flex flex-col gap-3">
              <div className="rounded-xl border border-slate-800 bg-slate-900 p-3.5">
                <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2.5">
                  Quick Menu Shortcuts
                </h2>
                <div className="grid grid-cols-2 lg:grid-cols-1 gap-1.5">
                  {QUICK_COMMANDS.map((cmd) => (
                    <button
                      key={cmd.value}
                      type="button"
                      disabled={exited}
                      title={cmd.hint}
                      onClick={() => void sendLine(cmd.value)}
                      className="text-left px-2.5 py-1.5 rounded-md bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 hover:border-cyan-500/40 text-xs text-slate-200 transition disabled:opacity-40"
                    >
                      <span className="font-mono font-medium text-cyan-300">{cmd.label}</span>
                    </button>
                  ))}
                  <button
                    type="button"
                    disabled={exited}
                    onClick={() => void sendLine('')}
                    className="text-left px-2.5 py-1.5 rounded-md bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 text-xs text-slate-300 transition disabled:opacity-40"
                  >
                    Press [Enter] (Continue / Default)
                  </button>
                </div>
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-900 p-3.5 text-xs text-slate-300 space-y-2">
                <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Run Locally in Terminal
                </h2>
                <p className="text-slate-400 leading-relaxed">
                  100% Python Standard Library (zero external dependencies):
                </p>
                <pre className="p-2.5 rounded-md bg-slate-950 border border-slate-800 font-mono text-[11px] text-cyan-200 whitespace-pre-wrap break-words">
{`python3 main.py
python3 -m unittest discover -s tests -v`}
                </pre>
              </div>
            </aside>
          </div>
        ) : (
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-[310px_1fr] gap-4 min-h-[540px]">
            <aside className="rounded-xl border border-slate-800 bg-slate-900 p-3.5 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Local Storage &amp; Exports
                </h2>
                <button
                  type="button"
                  onClick={() => void refreshFiles()}
                  aria-label="Refresh workspace files"
                  className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="space-y-1.5 overflow-y-auto">
                {files.map((file) => (
                  <button
                    key={file.path}
                    type="button"
                    onClick={() => void loadFileContent(file.path)}
                    className={`w-full text-left px-3 py-2 rounded-lg border text-xs transition ${
                      selectedFile === file.path
                        ? 'bg-cyan-500/15 border-cyan-400/50 text-cyan-100'
                        : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-2 font-mono font-medium">
                      <FileCode2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span className="truncate">{file.path}</span>
                    </div>
                    <div className="mt-0.5 text-[11px] text-slate-400 flex justify-between">
                      <span>{file.category}</span>
                      <span>{(file.size / 1024).toFixed(1)} KB</span>
                    </div>
                  </button>
                ))}
              </div>
            </aside>

            <section
              aria-label="File Content Viewer"
              className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden flex flex-col max-h-[calc(100vh-140px)]"
            >
              <div className="px-4 py-2.5 border-b border-slate-800 flex items-center justify-between bg-slate-900">
                <span className="font-mono text-xs text-cyan-300">{selectedFile}</span>
                <button
                  type="button"
                  onClick={() => void loadFileContent(selectedFile)}
                  className="text-xs text-slate-400 hover:text-slate-200 inline-flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" />
                  Reload
                </button>
              </div>
              <pre className="flex-1 overflow-auto p-4 font-mono text-xs text-slate-200 bg-[#080d1a] leading-relaxed whitespace-pre">
                {loadingFile ? 'Loading file...' : fileContent}
              </pre>
            </section>
          </div>
        )}
      </main>
    </div>
  );
}
