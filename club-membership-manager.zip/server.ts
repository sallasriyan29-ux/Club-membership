import { spawn, type ChildProcessWithoutNullStreams } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';

interface TerminalSession {
  id: string;
  proc: ChildProcessWithoutNullStreams;
  output: string;
  exited: boolean;
  exitCode: number | null;
  lastActivity: number;
}

const sessions = new Map<string, TerminalSession>();

const MAX_OUTPUT_CHARS = 250_000;
const SESSION_TTL_MS = 30 * 60 * 1000;

function cleanupStaleSessions(): void {
  const now = Date.now();
  for (const [id, session] of sessions.entries()) {
    if (now - session.lastActivity > SESSION_TTL_MS) {
      if (!session.exited) {
        session.proc.kill('SIGTERM');
      }
      sessions.delete(id);
    }
  }
}

setInterval(cleanupStaleSessions, 60_000).unref();

function startPythonSession(): TerminalSession {
  const id = crypto.randomUUID();
  const proc = spawn('python3', ['-u', 'main.py'], {
    cwd: process.cwd(),
    env: { ...process.env, PYTHONUNBUFFERED: '1' },
  });

  const session: TerminalSession = {
    id,
    proc,
    output: '',
    exited: false,
    exitCode: null,
    lastActivity: Date.now(),
  };

  const append = (chunk: Buffer) => {
    session.lastActivity = Date.now();
    session.output += chunk.toString('utf-8');
    if (session.output.length > MAX_OUTPUT_CHARS) {
      session.output = session.output.slice(session.output.length - MAX_OUTPUT_CHARS);
    }
  };

  proc.stdout.on('data', append);
  proc.stderr.on('data', append);
  proc.on('close', (code) => {
    session.exited = true;
    session.exitCode = code;
    session.lastActivity = Date.now();
  });

  sessions.set(id, session);
  return session;
}

function listWorkspaceFiles(): Array<{ path: string; category: string; size: number }> {
  const folders = ['data', 'exports'];
  const items: Array<{ path: string; category: string; size: number }> = [];
  for (const folder of folders) {
    const absFolder = path.resolve(process.cwd(), folder);
    if (!fs.existsSync(absFolder)) {
      continue;
    }
    const entries = fs.readdirSync(absFolder).sort();
    for (const name of entries) {
      if (name.endsWith('.tmp') || name.includes('.corrupt.')) {
        continue;
      }
      const full = path.join(absFolder, name);
      const stat = fs.statSync(full);
      if (stat.isFile()) {
        items.push({
          path: `${folder}/${name}`,
          category: folder === 'data' ? 'Storage & Sample Data' : 'Exported Reports',
          size: stat.size,
        });
      }
    }
  }
  return items;
}

async function createServer(): Promise<void> {
  const app = express();
  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, runtime: 'python3 + express' });
  });

  app.post('/api/terminal/start', (_req, res) => {
    const session = startPythonSession();
    res.json({ sessionId: session.id });
  });

  app.get('/api/terminal/output', (req, res) => {
    const sessionId = String(req.query.sessionId || '');
    const offset = Math.max(0, Number.parseInt(String(req.query.offset || '0'), 10) || 0);
    const session = sessions.get(sessionId);
    if (!session) {
      res.status(404).json({ error: 'Terminal session not found.' });
      return;
    }
    session.lastActivity = Date.now();
    const safeOffset = Math.min(offset, session.output.length);
    const chunk = session.output.slice(safeOffset);
    res.json({
      chunk,
      nextOffset: session.output.length,
      exited: session.exited,
      exitCode: session.exitCode,
    });
  });

  app.post('/api/terminal/input', (req, res) => {
    const sessionId = String(req.body?.sessionId || '');
    const line = String(req.body?.input ?? '');
    const session = sessions.get(sessionId);
    if (!session) {
      res.status(404).json({ error: 'Terminal session not found.' });
      return;
    }
    if (session.exited) {
      res.status(409).json({ error: 'Python process has already exited.' });
      return;
    }
    session.lastActivity = Date.now();
    // Echo input cleanly into the terminal log so the transcript reads naturally
    session.output += `${line}\n`;
    session.proc.stdin.write(`${line}\n`);
    res.json({ ok: true });
  });

  app.post('/api/terminal/stop', (req, res) => {
    const sessionId = String(req.body?.sessionId || '');
    const session = sessions.get(sessionId);
    if (session) {
      if (!session.exited) {
        session.proc.kill('SIGTERM');
      }
      sessions.delete(sessionId);
    }
    res.json({ ok: true });
  });

  app.get('/api/files', (_req, res) => {
    res.json({ files: listWorkspaceFiles() });
  });

  app.get('/api/file', (req, res) => {
    const relPath = String(req.query.path || '');
    const allowed = listWorkspaceFiles().find((f) => f.path === relPath);
    if (!allowed) {
      res.status(404).json({ error: 'File not found or not accessible.' });
      return;
    }
    const absPath = path.resolve(process.cwd(), allowed.path);
    const content = fs.readFileSync(absPath, 'utf-8');
    res.json({ path: allowed.path, content });
  });

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const port = Number(process.env.PORT || 3000);
  app.listen(port, '0.0.0.0', () => {
    console.log(`Club Membership Manager bridge listening on http://0.0.0.0:${port}`);
  });
}

createServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
