# Campus Innovators & Builders Club — Executive Summary Report

- **Generated At:** 2026-11-20 17:43:01
- **Club Health Status:** `ATTENTION REQUIRED`
- **Total Members:** 40 (34 Active, 85.0% Active Rate)
- **Events Tracked:** 8 (40 participation records)
- **Membership Lists:** 5

## Financial & Engagement KPIs

| Metric | Value |
| :--- | :--- |
| Dues Collected | $1375.00 |
| Outstanding Dues | $195.00 |
| Dues Compliance Rate | 81.6% |
| Avg Events Attended / Member | 4.8 |
| Total Volunteer / Lab Hours | 123.0 hrs |
| Average Event Feedback | 4.67 / 5.0 |

## Membership Status Breakdown

| Status | Count |
| :--- | ---: |
| Active | 34 |
| Alumni | 2 |
| Inactive | 1 |
| Pending | 2 |
| Suspended | 1 |

## Membership Tier Breakdown

| Tier | Count |
| :--- | ---: |
| Gold | 8 |
| Honorary | 2 |
| Silver | 11 |
| Standard | 19 |

## Top Engaged Members

| Member ID | Name | Role | Tier | Events Attended |
| :--- | :--- | :--- | :--- | ---: |
| MEM-1016 | Benjamin Ross | Member | Standard | 15 |
| MEM-1001 | Aarav Mehta | President | Gold | 14 |
| MEM-1002 | Maya Lin | Vice President | Gold | 12 |
| MEM-1029 | Aria Montgomery | Member | Standard | 11 |
| MEM-1004 | Sofia Rodriguez | Secretary | Silver | 11 |

## Threshold Warnings & Anomalies

| Severity | Code | Entity | Message |
| :--- | :--- | :--- | :--- |
| **CRITICAL** | `OVERDUE_RENEWAL` | Member `MEM-1009` | Chloe Dubois (MEM-1009) renewal overdue by 36 day(s) (due 2026-10-15). |
| **CRITICAL** | `OVERDUE_RENEWAL` | Member `MEM-1017` | Isabella Rossi (MEM-1017) renewal overdue by 71 day(s) (due 2026-09-10). |
| **WARNING** | `EVENT_NEAR_CAPACITY` | Event `EVT-206` | Event 'Winter Project Showcase Prep' (EVT-206) is at 90% capacity (9/10). |
| **WARNING** | `UNPAID_ACTIVE_DUES` | Member `MEM-1009` | Active member Chloe Dubois (MEM-1009) has unpaid dues ($45.00). |
| **WARNING** | `UNPAID_ACTIVE_DUES` | Member `MEM-1017` | Active member Isabella Rossi (MEM-1017) has unpaid dues ($25.00). |
| **WARNING** | `UNPAID_ACTIVE_DUES` | Member `MEM-1026` | Active member Owen Mercer (MEM-1026) has unpaid dues ($25.00). |
| **INFO** | `ZERO_ENGAGEMENT` | Member `MEM-1013` | Hannah Patel (MEM-1013) joined 2025-04-04 with 0 events attended. |
